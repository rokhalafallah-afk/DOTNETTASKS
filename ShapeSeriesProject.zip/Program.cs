namespace ShapeSeriesProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ==========================================
            // PART 1: Shape Series
            // ==========================================

            Console.WriteLine("=================================");
            Console.WriteLine("PART 1: SHAPE SERIES");
            Console.WriteLine("=================================");

            SquareSeries squareSeries = new SquareSeries();

            Console.WriteLine("\nFirst 10 Square Areas:");
            PrintTenShapes(squareSeries);

            CircleSeries circleSeries = new CircleSeries();

            Console.WriteLine("\nFirst 10 Circle Areas:");
            PrintTenShapes(circleSeries);

            // ==========================================
            // PART 2: Sorting Shapes
            // ==========================================

            Console.WriteLine("\n=================================");
            Console.WriteLine("PART 2: SORTING SHAPES");
            Console.WriteLine("=================================");

            Shape[] shapes =
            {
                new Shape("Square", 25),
                new Shape("Circle", 12.56),
                new Shape("Rectangle", 40),
                new Shape("Triangle", 15),
                new Shape("Circle", 78.54),
                new Shape("Square", 9)
            };

            Console.WriteLine("\nBefore Sorting:");

            foreach (Shape shape in shapes)
                Console.WriteLine(shape);

            Array.Sort(shapes);

            Console.WriteLine("\nAfter Sorting by Area:");

            foreach (Shape shape in shapes)
                Console.WriteLine(shape);

            // ==========================================
            // PART 3: Geometric Shape Hierarchy
            // ==========================================

            Console.WriteLine("\n=================================");
            Console.WriteLine("PART 3: SHAPE HIERARCHY");
            Console.WriteLine("=================================");

            GeometricShape rectangle = new Rectangle(10, 5);
            GeometricShape triangle = new Triangle(8, 6);

            Console.WriteLine("\nRectangle:");
            Console.WriteLine($"Area: {rectangle.CalculateArea():F2}");
            Console.WriteLine($"Perimeter: {rectangle.Perimeter:F2}");

            Console.WriteLine("\nTriangle:");
            Console.WriteLine($"Area: {triangle.CalculateArea():F2}");
            Console.WriteLine($"Perimeter: {triangle.Perimeter:F2}");

            // ==========================================
            // PART 4: Selection Sort
            // ==========================================

            Console.WriteLine("\n=================================");
            Console.WriteLine("PART 4: SELECTION SORT");
            Console.WriteLine("=================================");

            int[] areas =
            {
                25, 9, 40, 15, 78, 12
            };

            Console.WriteLine("\nBefore Selection Sort:");
            PrintArray(areas);

            SelectionSort(areas);

            Console.WriteLine("\nAfter Selection Sort:");
            PrintArray(areas);

            // ==========================================
            // PART 5: Factory Pattern
            // ==========================================

            Console.WriteLine("\n=================================");
            Console.WriteLine("PART 5: FACTORY PATTERN");
            Console.WriteLine("=================================");

            ShapeFactory factory = new ShapeFactory();

            GeometricShape factoryRectangle =
                factory.CreateShape("rectangle", 12, 5);

            GeometricShape factoryTriangle =
                factory.CreateShape("triangle", 10, 8);

            Console.WriteLine("\nFactory Rectangle:");
            Console.WriteLine($"Area: {factoryRectangle.CalculateArea():F2}");
            Console.WriteLine($"Perimeter: {factoryRectangle.Perimeter:F2}");

            Console.WriteLine("\nFactory Triangle:");
            Console.WriteLine($"Area: {factoryTriangle.CalculateArea():F2}");
            Console.WriteLine($"Perimeter: {factoryTriangle.Perimeter:F2}");

            Console.WriteLine("\n=================================");
            Console.WriteLine("PROGRAM FINISHED");
            Console.WriteLine("=================================");

            Console.ReadKey();
        }

        public static void PrintTenShapes(IShapeSeries series)
        {
            series.ResetSeries();

            for (int i = 0; i < 10; i++)
            {
                series.GetNextArea();
                Console.WriteLine(
                    $"Shape {i + 1}: {series.CurrentShapeArea}");
            }
        }

        public static void SelectionSort(int[] numbers)
        {
            for (int i = 0; i < numbers.Length - 1; i++)
            {
                int minIndex = i;

                for (int j = i + 1; j < numbers.Length; j++)
                {
                    if (numbers[j] < numbers[minIndex])
                        minIndex = j;
                }

                if (minIndex != i)
                {
                    int temp = numbers[i];
                    numbers[i] = numbers[minIndex];
                    numbers[minIndex] = temp;
                }
            }
        }

        public static void PrintArray(int[] numbers)
        {
            foreach (int number in numbers)
                Console.Write(number + " ");

            Console.WriteLine();
        }
    }
}
