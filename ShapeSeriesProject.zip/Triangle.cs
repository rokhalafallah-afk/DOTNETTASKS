namespace ShapeSeriesProject
{
    public class Triangle : GeometricShape
    {
        public Triangle(double baseLength, double height)
            : base(baseLength, height)
        {
        }

        public override double CalculateArea()
        {
            return 0.5 * Dimension1 * Dimension2;
        }

        public override double Perimeter
        {
            get
            {
                // Assumes an isosceles triangle because only base and height are provided.
                double side = Math.Sqrt(
                    Math.Pow(Dimension1 / 2, 2) +
                    Math.Pow(Dimension2, 2));

                return Dimension1 + (2 * side);
            }
        }
    }
}
