namespace ShapeSeriesProject
{
    public class CircleSeries : IShapeSeries
    {
        private int radius = 0;

        public int CurrentShapeArea { get; set; }

        public void GetNextArea()
        {
            radius++;
            double area = Math.PI * radius * radius;
            CurrentShapeArea = (int)Math.Round(area);
        }

        public void ResetSeries()
        {
            radius = 0;
            CurrentShapeArea = 0;
        }
    }
}
