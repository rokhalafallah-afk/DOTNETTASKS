﻿using System;
using System.Text;

class StringAndObjectDemos
{
    #region Problem 10 - Parse vs Convert.ToInt32
    public static void Problem10()
    {
        Console.WriteLine("---- Problem 10: Parse vs Convert.ToInt32 ----");

        Console.Write("Enter a number: ");
        string input = Console.ReadLine();

        try
        {
            int resultParse = int.Parse(input);
            Console.WriteLine("int.Parse result: " + resultParse);

            int resultConvert = Convert.ToInt32(input);
            Console.WriteLine("Convert.ToInt32 result: " + resultConvert);
        }
        catch (FormatException)
        {
            Console.WriteLine("Error: Input is not a valid number format.");
        }
        catch (OverflowException)
        {
            Console.WriteLine("Error: Number is too large or too small.");
        }
        catch (ArgumentNullException)
        {
            Console.WriteLine("Error: Input was null.");
        }

        Console.WriteLine();

        // ANSWER: What is the difference between int.Parse and Convert.ToInt32
        // when handling null inputs?
        // - int.Parse(null) throws an ArgumentNullException immediately, because
        //   Parse expects a non-null string and has no special handling for null.
        // - Convert.ToInt32(null) does NOT throw an exception for null input.
        //   Instead, it returns 0, because Convert.ToInt32 has built-in logic
        //   that treats a null argument as equivalent to zero.
        // In short: Parse is stricter with null, Convert.ToInt32 is more forgiving.
    }
    #endregion

    #region Problem 11 - TryParse
    public static void Problem11()
    {
        Console.WriteLine("---- Problem 11: TryParse ----");

        Console.Write("Enter a number: ");
        string input = Console.ReadLine();

        bool isValid = int.TryParse(input, out int number);

        if (isValid)
        {
            Console.WriteLine("Valid number entered: " + number);
        }
        else
        {
            Console.WriteLine("Error: '" + input + "' is not a valid integer.");
        }

        Console.WriteLine();

        // ANSWER: Why is TryParse recommended over Parse in user-facing applications?
        // - TryParse does not throw an exception when conversion fails; it simply
        //   returns false and sets the output value to the type's default (0 for int).
        // - This avoids the performance cost and program interruption caused by
        //   exceptions, and lets you handle invalid input gracefully with a simple
        //   if-check, rather than wrapping code in try-catch blocks.
        // - Since user input is unpredictable (typos, empty strings, letters, etc.),
        //   TryParse leads to more robust, crash-resistant applications.
    }
    #endregion

    #region Problem 12 - GetHashCode with object variable
    public static void Problem12()
    {
        Console.WriteLine("---- Problem 12: GetHashCode with Object Variable ----");

        object obj;

        obj = 42;
        Console.WriteLine("int value: " + obj + " | HashCode: " + obj.GetHashCode());

        obj = "Hello";
        Console.WriteLine("string value: " + obj + " | HashCode: " + obj.GetHashCode());

        obj = 3.14;
        Console.WriteLine("double value: " + obj + " | HashCode: " + obj.GetHashCode());

        Console.WriteLine();

        // ANSWER: Explain the real purpose of the GetHashCode() method.
        // - GetHashCode() returns an integer that represents a "hash" of an object's
        //   value, primarily used to efficiently organize and retrieve objects in
        //   hash-based collections like Dictionary, Hashtable, and HashSet.
        // - It allows these collections to quickly narrow down where an object
        //   should be stored/found instead of scanning every item (O(1) lookups
        //   instead of O(n)).
        // - It is NOT meant to generate unique IDs — two different objects can
        //   share the same hash code (a "collision"), and hash codes are not
        //   guaranteed to stay the same across different program runs.
        // - Objects considered equal (via Equals) should always return the same
        //   hash code.
    }
    #endregion

    #region Problem 13 - Reference Equality
    class Box
    {
        public int Value;
    }

    public static void Problem13()
    {
        Console.WriteLine("---- Problem 13: Reference Equality ----");

        // Create an object and assign it a value
        Box box1 = new Box();
        box1.Value = 100;

        // Create a second reference to the same object
        Box box2 = box1;

        // Modify the value using one reference
        box1.Value = 250;

        // Print the value using the other reference
        Console.WriteLine("box1.Value: " + box1.Value); // 250
        Console.WriteLine("box2.Value: " + box2.Value); // 250 (same object!)

        Console.WriteLine();

        // ANSWER: What is the significance of reference equality in .NET?
        // - Reference equality means two variables point to the exact same object
        //   in memory, not just objects with equal content/values.
        // - It matters because changes made through one reference are visible
        //   through any other reference to that same object — as shown above,
        //   modifying box1 also changes what box2 "sees."
        // - .NET distinguishes reference equality (ReferenceEquals / == for
        //   reference types by default) from value equality (Equals, which can be
        //   overridden to compare contents). Understanding this prevents bugs
        //   where developers assume they have independent copies of an object
        //   when they actually share the same instance.
    }
    #endregion

    #region Problem 14 - String Immutability
    public static void Problem14()
    {
        Console.WriteLine("---- Problem 14: String Immutability ----");

        string greeting = "Hi Willy";
        Console.WriteLine("Before modification: " + greeting);
        Console.WriteLine("HashCode before: " + greeting.GetHashCode());

        greeting = greeting + " - Welcome!";
        Console.WriteLine("After modification: " + greeting);
        Console.WriteLine("HashCode after: " + greeting.GetHashCode());

        Console.WriteLine();

        // ANSWER: Why is string immutable in C#?
        // - A string in C# cannot be changed after it is created. Every time you
        //   "modify" a string (e.g., concatenation), a brand-new string object is
        //   created in memory, and the variable is simply repointed to it.
        // - This is why the HashCode changes above — "greeting" now refers to an
        //   entirely different object, not the original one being edited in place.
        // - Reasons for immutability:
        //   1. Thread safety — immutable objects can be shared across threads
        //      without synchronization issues, since their state can't change.
        //   2. Security — strings are used for things like file paths and
        //      connection strings; immutability prevents them from being altered
        //      unexpectedly after validation.
        //   3. Performance/caching — the CLR can safely intern (cache and reuse)
        //      identical string literals, saving memory.
        //   4. Predictability — passing a string to a method guarantees the
        //      original value can't be silently changed by that method.
    }
    #endregion

    #region Problem 15 - StringBuilder
    public static void Problem15()
    {
        Console.WriteLine("---- Problem 15: StringBuilder ----");

        StringBuilder sb = new StringBuilder("Hi Willy");
        Console.WriteLine("Before modification: " + sb.ToString());
        Console.WriteLine("HashCode before: " + sb.GetHashCode());

        sb.Append(" - Welcome to C#!");
        Console.WriteLine("After modification: " + sb.ToString());
        Console.WriteLine("HashCode after: " + sb.GetHashCode());

        Console.WriteLine();

        // ANSWER: How does StringBuilder address the inefficiencies of string
        // concatenation?
        // - Unlike string, StringBuilder is mutable — it uses an internal
        //   resizable character buffer that can be modified directly in place.
        // - Notice the HashCode stays the SAME before and after modification
        //   above, because it's still the same object in memory, just with
        //   updated internal content — no new object was created.
        // - Regular string concatenation (+=) creates a brand-new string object
        //   every time, which means repeated concatenation in a loop creates many
        //   throwaway objects, wasting memory and CPU on garbage collection.

        // ANSWER: Why is StringBuilder faster for large-scale string modifications?
        // - StringBuilder pre-allocates a buffer (capacity) and appends/edits
        //   characters directly within that buffer, only resizing when it runs
        //   out of space (and it grows efficiently, e.g., doubling in size).
        // - This means for large amounts of concatenation (e.g., building a big
        //   string in a loop with hundreds/thousands of iterations), StringBuilder
        //   performs far fewer memory allocations than repeated string
        //   concatenation, resulting in significantly better performance
        //   (often changing an O(n²) operation into roughly O(n)).
    }
    #endregion

    #region Problem 16 - String Formatting Methods
    public static void Problem16()
    {
        Console.WriteLine("---- Problem 16: String Formatting Methods ----");

        Console.Write("Enter first integer: ");
        int input1 = int.Parse(Console.ReadLine());

        Console.Write("Enter second integer: ");
        int input2 = int.Parse(Console.ReadLine());

        // Concatenation (+ operator)
        string concatResult = "Sum is " + input1 + "+" + input2 + "=" + (input1 + input2);
        Console.WriteLine(concatResult);

        // Composite formatting (string.Format)
        string formatResult = string.Format("Sum is {0}+{1}={2}", input1, input2, input1 + input2);
        Console.WriteLine(formatResult);

        // String interpolation ($)
        string interpolationResult = $"Sum is {input1}+{input2}={input1 + input2}";
        Console.WriteLine(interpolationResult);

        Console.WriteLine();

        // ANSWER: Which string formatting method is most used and why?
        // - String interpolation ($"...") is the most commonly used and recommended
        //   method in modern C# (introduced in C# 6.0).
        // - Reasons:
        //   1. Readability — the expressions/variables appear directly inside the
        //      string, making it easy to see exactly what will be output, unlike
        //      string.Format's numbered placeholders {0}, {1}, which require
        //      cross-referencing arguments.
        //   2. Less error-prone — no risk of mismatching placeholder indexes with
        //      argument order (a common bug with string.Format).
        //   3. Compile-time checking — the compiler verifies that referenced
        //      variables/expressions exist and are valid.
        //   4. Conciseness — avoids messy multiple "+" concatenations for readability
        //      and avoids the verbosity of string.Format's argument list.
        // - Plain concatenation (+) is generally discouraged for building
        //   formatted or multi-variable strings because it becomes hard to read
        //   and is less efficient for repeated operations.
    }
    #endregion

    #region Problem 17 - StringBuilder Operations
    public static void Problem17()
    {
        Console.WriteLine("---- Problem 17: StringBuilder Operations ----");

        StringBuilder sb = new StringBuilder("Hello World");
        Console.WriteLine("Initial: " + sb.ToString());

        // Append text
        sb.Append(" - Programming in C#");
        Console.WriteLine("After Append: " + sb.ToString());

        // Replace a substring
        sb.Replace("World", "Willy");
        Console.WriteLine("After Replace: " + sb.ToString());

        // Insert a string at a specific position
        sb.Insert(0, "Greeting: ");
        Console.WriteLine("After Insert: " + sb.ToString());

        // Remove a portion of text
        sb.Remove(0, 10); // removes "Greeting: "
        Console.WriteLine("After Remove: " + sb.ToString());

        Console.WriteLine();

        // ANSWER: Explain how StringBuilder is designed to handle frequent
        // modifications compared to strings.
        // - StringBuilder maintains a single mutable buffer in memory, and all
        //   operations (Append, Replace, Insert, Remove) directly modify that
        //   buffer's contents without creating a new object each time.
        // - Regular strings are immutable, so every modification (concatenation,
        //   replace, etc.) must allocate a brand-new string object in memory and
        //   copy over the relevant characters — wasteful when done repeatedly.
        // - StringBuilder's buffer has spare capacity built in, so small
        //   additions often don't require any reallocation at all; it only grows
        //   the buffer (typically by doubling) when it actually runs out of room.
        // - This design makes StringBuilder the appropriate choice whenever a
        //   string needs to be built or changed many times (e.g., in a loop,
        //   or with multiple sequential edits like above), since it minimizes
        //   memory allocation and garbage collection overhead.
    }
    #endregion
}