﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Problem1.Run();
        Problem2.Run();
        Problem3.Run();
        Problem4.Run();
        Problem5.Run();
        Problem6.Run();
        Problem7.Run();
        Problem8.Run();
        Problem9.Run();

        StringAndObjectDemos.Problem10();
        StringAndObjectDemos.Problem11();
        StringAndObjectDemos.Problem12();
        StringAndObjectDemos.Problem13();
        StringAndObjectDemos.Problem14();
        StringAndObjectDemos.Problem15();
        StringAndObjectDemos.Problem16();
        StringAndObjectDemos.Problem17();

        Console.WriteLine("\nAll problems executed. Press any key to exit.");
        Console.ReadKey();
    }
}