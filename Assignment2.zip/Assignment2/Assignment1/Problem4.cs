﻿using System;

class Person
{
    public string Name;
}

class Problem4
{
    public static void Run()
    {
        Console.WriteLine("---- Problem 4: Reference Types ----");

        Person person1 = new Person();
        person1.Name = "Alice";

        // person2 references the SAME object as person1
        Person person2 = person1;

        // Changing person2's Name also changes person1's Name
        person2.Name = "Bob";

        Console.WriteLine("person1.Name: " + person1.Name); // Output: Bob
        Console.WriteLine("person2.Name: " + person2.Name); // Output: Bob
        Console.WriteLine();
    }
}