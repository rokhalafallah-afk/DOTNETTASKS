﻿using System;

class Problem5
{
    public static void Run()
    {
        Console.WriteLine("---- Problem 5: Calculator (x=15, y=4) ----");

        int x = 15;
        int y = 4;

        int sum = x + y;
        int difference = x - y;
        int product = x * y;
        double division = (double)x / y;
        int remainder = x % y;

        Console.WriteLine("Sum: " + sum);
        Console.WriteLine("Difference: " + difference);
        Console.WriteLine("Product: " + product);
        Console.WriteLine("Division: " + division);
        Console.WriteLine("Remainder: " + remainder);
        Console.WriteLine();
    }
}