﻿using System;

class Problem1
{
    public static void Run()
    {
        Console.WriteLine("---- Problem 1: Comments ----");

        // Single-line comment: Declaring two integer variables x and y
        int x = 10;
        int y = 20;

        /* Multi-line comment:
           This block calculates the sum of x and y
           and stores the result in the variable 'sum' */
        int sum = x + y;

        // Single-line comment: Print the sum to the console
        Console.WriteLine("Sum: " + sum);
        Console.WriteLine();
    }
}