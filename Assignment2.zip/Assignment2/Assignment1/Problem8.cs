﻿using System;

class Problem8
{
    public static void Run()
    {
        Console.WriteLine("---- Problem 8: Parse Age ----");

        Console.Write("Enter your age: ");
        string ageInput = Console.ReadLine();

        try
        {
            int age = int.Parse(ageInput);

            if (age > 0)
            {
                Console.WriteLine("Valid age: " + age);
            }
            else
            {
                Console.WriteLine("Age must be greater than 0.");
            }
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid input. Please enter a numeric value.");
        }
        Console.WriteLine();
    }
}