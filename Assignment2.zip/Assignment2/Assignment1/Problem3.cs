﻿using System;

class Problem3
{
    public static void Run()
    {
        Console.WriteLine("---- Problem 3: Variable Declarations ----");

        string fullName = "John Michael Doe";   // camelCase for local variables
        int age = 25;
        double monthlySalary = 5500.75;
        bool isStudent = false;

        Console.WriteLine("Full Name: " + fullName);
        Console.WriteLine("Age: " + age);
        Console.WriteLine("Monthly Salary: " + monthlySalary);
        Console.WriteLine("Is Student: " + isStudent);
        Console.WriteLine();
    }
}