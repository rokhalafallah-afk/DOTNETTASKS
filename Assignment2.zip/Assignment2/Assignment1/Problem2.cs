﻿using System;

class Problem2
{
    public static void Run()
    {
        Console.WriteLine("---- Problem 2: Fixed Code ----");

        int x = 10;      // fixed: assign an integer literal, not a string
        int y = 20;      // fixed: declare y before using it
        Console.WriteLine("x + y = " + (x + y));   // fixed: capital "C" in Console
        Console.WriteLine();
    }
}