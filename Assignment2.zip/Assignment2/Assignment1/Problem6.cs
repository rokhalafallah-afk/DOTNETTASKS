﻿using System;

class Problem6
{
    public static void Run()
    {
        Console.WriteLine("---- Problem 6: Greater Than 10 and Even ----");

        Console.Write("Enter a number: ");
        int number = int.Parse(Console.ReadLine());

        if (number > 10 && number % 2 == 0)
        {
            Console.WriteLine(number + " is greater than 10 and even.");
        }
        else
        {
            Console.WriteLine(number + " does not meet both conditions.");
        }
        Console.WriteLine();
    }
}