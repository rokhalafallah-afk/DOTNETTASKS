﻿using System;

class Problem7
{
    public static void Run()
    {
        Console.WriteLine("---- Problem 7: Casting ----");

        Console.Write("Enter a double value: ");
        double input = double.Parse(Console.ReadLine());

        // Implicit casting example (int to double — no data loss, automatic)
        int wholeNumber = 10;
        double implicitResult = wholeNumber;
        Console.WriteLine("Implicit cast result (int to double): " + implicitResult);

        // Explicit casting (double to int — must be done manually, may lose data)
        int explicitResult = (int)input;
        Console.WriteLine("Explicit cast result (double to int): " + explicitResult);
        Console.WriteLine();
    }
}