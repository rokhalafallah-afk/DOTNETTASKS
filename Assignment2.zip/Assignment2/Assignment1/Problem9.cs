﻿using System;

class Problem9
{
    public static void Run()
    {
        Console.WriteLine("---- Problem 9: Prefix vs Postfix ----");

        int x = 5;
        int a = ++x; // Prefix: increments first, then uses value
        Console.WriteLine("Prefix: x = " + x + ", a = " + a); // x = 6, a = 6

        x = 5; // reset
        int b = x++; // Postfix: uses value first, then increments
        Console.WriteLine("Postfix: x = " + x + ", b = " + b); // x = 6, b = 5

        // Combined expression
        x = 5;
        int y = ++x + x++;
        Console.WriteLine("Combined: x = " + x + ", y = " + y); // x = 7, y = 12
        Console.WriteLine();
    }
}