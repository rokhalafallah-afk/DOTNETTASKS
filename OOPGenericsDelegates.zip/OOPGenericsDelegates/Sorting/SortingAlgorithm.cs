namespace OOPGenericsDelegates.Sorting;

// Generic selection-sort implementation. T must implement IComparable<T> so the
// class works for any type (int, Employee, Manager, ...) without duplicating
// sorting logic per type.
public class SortingAlgorithm<T> where T : IComparable<T>
{
    // Ascending selection sort, in place.
    public static void Sort(T[] array)
    {
        for (int i = 0; i < array.Length - 1; i++)
        {
            int minIndex = i;
            for (int j = i + 1; j < array.Length; j++)
            {
                if (array[j].CompareTo(array[minIndex]) < 0)
                    minIndex = j;
            }
            if (minIndex != i)
                Swap(ref array[i], ref array[minIndex]);
        }
    }

    // Standalone generic utility method - not tied to T, so it can swap
    // elements of ANY array, not just T[].
    public static void Swap<TItem>(ref TItem a, ref TItem b)
    {
        (a, b) = (b, a);
    }

    // Returns the default value for any type: 0/false/'\0' for value types,
    // null for reference types.
    public static TResult? GetDefault<TResult>()
    {
        return default(TResult);
    }

    // Constrained standalone method: TCloneable must implement ICloneable.
    // Demonstrates cloning an array before sorting it, so the original is untouched.
    public static TCloneable[] CloneArray<TCloneable>(TCloneable[] source) where TCloneable : ICloneable
    {
        var clone = new TCloneable[source.Length];
        for (int i = 0; i < source.Length; i++)
            clone[i] = (TCloneable)source[i].Clone();
        return clone;
    }
}
