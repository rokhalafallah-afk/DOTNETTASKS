namespace OOPGenericsDelegates.Sorting;

// Comparer-driven generic sort: instead of requiring T : IComparable<T>,
// the caller supplies a Comparison<T> (a delegate), so the SAME method can
// sort ints descending, strings by length, employees by salary-then-name, etc.
public class SortingTwo<T>
{
    public static void Sort(T[] array, Comparison<T> comparer)
    {
        // Simple insertion sort using the supplied comparer delegate.
        for (int i = 1; i < array.Length; i++)
        {
            T current = array[i];
            int j = i - 1;
            while (j >= 0 && comparer(array[j], current) > 0)
            {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = current;
        }
    }
}
