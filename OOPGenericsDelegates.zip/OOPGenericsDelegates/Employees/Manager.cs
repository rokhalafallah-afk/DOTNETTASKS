namespace OOPGenericsDelegates.Employees;

// Inherits Employee and adds its own IComparable<Manager>, still comparing by Salary.
// This lets Manager objects be sorted on their own terms while remaining
// substitutable anywhere an Employee is expected.
public class Manager : Employee, IComparable<Manager>
{
    public int DirectReports { get; set; }

    public Manager(string name, double salary, int directReports)
        : base(name, salary)
    {
        DirectReports = directReports;
    }

    public int CompareTo(Manager? other)
    {
        if (other is null) return 1;
        return Salary.CompareTo(other.Salary);
    }

    public override string ToString() => $"{Name} (${Salary:N0}, manages {DirectReports})";
}
