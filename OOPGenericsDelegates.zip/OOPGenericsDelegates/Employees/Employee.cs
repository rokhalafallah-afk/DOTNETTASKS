namespace OOPGenericsDelegates.Employees;

// Implements IComparable<Employee> so generic sorting classes can compare
// by Salary without needing a separate comparer, and ICloneable so it can
// satisfy an "ICloneable" generic constraint.
public class Employee : IComparable<Employee>, ICloneable
{
    public string Name { get; set; }
    public double Salary { get; set; }

    public Employee(string name, double salary)
    {
        Name = name;
        Salary = salary;
    }

    // Ascending by Salary by default.
    public int CompareTo(Employee? other)
    {
        if (other is null) return 1;
        return Salary.CompareTo(other.Salary);
    }

    public object Clone()
    {
        // Shallow clone is sufficient here since Name/Salary are immutable-ish value/string types.
        return new Employee(Name, Salary);
    }

    public override string ToString() => $"{Name} (${Salary:N0})";
}
