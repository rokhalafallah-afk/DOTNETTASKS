using OOPGenericsDelegates.Employees;

namespace OOPGenericsDelegates.Delegates;

// A custom generic delegate: takes a T, returns an R.
// (Func<T,TResult> below is the built-in equivalent - both are shown for comparison.)
public delegate R Transformer<T, R>(T input);

public static class DelegateDemos
{
    // ---- Employee comparison via Func<T,T,bool> --------------------------
    // Sorts employees by Name length using a simple bubble pass driven by
    // a Func<Employee,Employee,bool> that returns true when the first
    // argument should come AFTER the second.
    public static Employee[] SortByNameLength(Employee[] employees)
    {
        Func<Employee, Employee, bool> isOutOfOrder =
            (a, b) => a.Name.Length > b.Name.Length;

        var result = (Employee[])employees.Clone();
        for (int i = 0; i < result.Length - 1; i++)
        {
            for (int j = 0; j < result.Length - i - 1; j++)
            {
                if (isOutOfOrder(result[j], result[j + 1]))
                    (result[j], result[j + 1]) = (result[j + 1], result[j]);
            }
        }
        return result;
    }

    // ---- Anonymous function vs. lambda expression -------------------------
    public static int[] SortAscendingWithAnonymousMethod(int[] numbers)
    {
        var result = (int[])numbers.Clone();
        Comparison<int> ascending = delegate (int a, int b) { return a.CompareTo(b); };
        Array.Sort(result, ascending);
        return result;
    }

    public static int[] SortAscendingWithLambda(int[] numbers)
    {
        var result = (int[])numbers.Clone();
        Array.Sort(result, (a, b) => a.CompareTo(b));
        return result;
    }

    // ---- Func<string,string>: string transformations -----------------------
    public static List<string> TransformStrings(List<string> input, Func<string, string> transform)
    {
        return input.Select(transform).ToList();
    }

    // ---- Func<int,int,int>: math operations --------------------------------
    public static int ApplyOperation(int a, int b, Func<int, int, int> operation) => operation(a, b);

    // ---- Custom generic delegate Transformer<T,R> --------------------------
    public static List<R> TransformList<T, R>(List<T> input, Transformer<T, R> transformer)
    {
        var results = new List<R>();
        foreach (var item in input)
            results.Add(transformer(item));
        return results;
    }

    // ---- Func<int,int>: square each element --------------------------------
    public static List<int> SquareAll(List<int> numbers)
    {
        Func<int, int> square = n => n * n;
        return numbers.Select(square).ToList();
    }

    // ---- Action<string>: print each string ----------------------------------
    public static void PrintAll(List<string> strings, Action<string> action)
    {
        foreach (var s in strings)
            action(s);
    }

    // ---- Predicate<int>: filter even numbers --------------------------------
    public static List<int> FilterEven(List<int> numbers)
    {
        Predicate<int> isEven = n => n % 2 == 0;
        return numbers.Where(n => isEven(n)).ToList();
    }

    // ---- Anonymous function filtering strings by a condition -----------------
    public static List<string> FilterWithAnonymousMethod(List<string> strings, Func<string, bool> condition)
    {
        return strings.Where(s => condition(s)).ToList();
    }

    // ---- Anonymous function performing a math operation -----------------------
    public static int ApplyAnonymousMathOp(int a, int b, Func<int, int, int> op) => op(a, b);

    // ---- Lambda expression filtering strings ------------------------------------
    public static List<string> FilterWithLambda(List<string> strings, Func<string, bool> condition)
    {
        return strings.Where(condition).ToList();
    }

    // ---- Lambda expression performing math on doubles ----------------------------
    public static double ApplyLambdaMathOp(double a, double b, Func<double, double, double> op) => op(a, b);
}
