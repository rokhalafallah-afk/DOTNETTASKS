using OOPGenericsDelegates.Delegates;
using OOPGenericsDelegates.Employees;
using OOPGenericsDelegates.Sorting;

void Section(string title)
{
    Console.WriteLine();
    Console.WriteLine($"=== {title} ===");
}

// 1) Generic SortingAlgorithm<T> sorting Employees by Salary ascending
Section("1) SortingAlgorithm<Employee> - sort by Salary ascending");
var employees = new[]
{
    new Employee("Sara", 62000),
    new Employee("Omar", 48000),
    new Employee("Lina", 75000),
    new Employee("Kareem", 55000),
};
SortingAlgorithm<Employee>.Sort(employees);
foreach (var e in employees) Console.WriteLine(e);

// 2) SortingTwo<int>.Sort with a lambda for descending order
Section("2) SortingTwo<int> - descending order via lambda");
var numbers = new[] { 5, 1, 9, 3, 7 };
SortingTwo<int>.Sort(numbers, (a, b) => b.CompareTo(a));
Console.WriteLine(string.Join(", ", numbers));

// 3) SortingTwo<string>.Sort with a comparer function for string length
Section("3) SortingTwo<string> - ascending by length");
var words = new[] { "banana", "fig", "kiwi", "apple", "pear" };
Comparison<string> byLength = (a, b) => a.Length.CompareTo(b.Length);
SortingTwo<string>.Sort(words, byLength);
Console.WriteLine(string.Join(", ", words));

// 4) Manager : Employee, IComparable<Manager>, sorted alongside Employees by Salary
Section("4) Manager objects sorted by Salary");
var managers = new[]
{
    new Manager("Huda", 91000, 5),
    new Manager("Tariq", 68000, 2),
    new Manager("Nadia", 84000, 8),
};
SortingAlgorithm<Manager>.Sort(managers);
foreach (var m in managers) Console.WriteLine(m);

// 5) Func<T,T,bool> comparing Employees by Name length
Section("5) Sort Employees by Name length via Func<Employee,Employee,bool>");
var byNameLength = DelegateDemos.SortByNameLength(employees);
foreach (var e in byNameLength) Console.WriteLine(e);

// 6) Anonymous method vs. lambda expression sorting ints ascending
Section("6) Ascending sort: anonymous method vs. lambda");
var unsorted = new[] { 8, 2, 6, 4, 1 };
Console.WriteLine("Anonymous method: " + string.Join(", ", DelegateDemos.SortAscendingWithAnonymousMethod(unsorted)));
Console.WriteLine("Lambda expression: " + string.Join(", ", DelegateDemos.SortAscendingWithLambda(unsorted)));

// 7) SortingAlgorithm<T>.Swap<T> demo
Section("7) Generic Swap<T> on an integer array");
var swapArray = new[] { 10, 20, 30 };
SortingAlgorithm<int>.Swap(ref swapArray[0], ref swapArray[2]);
Console.WriteLine(string.Join(", ", swapArray));

// 8) Multi-criteria sort: Employees by Salary, then Name on ties
Section("8) SortingTwo<Employee> - Salary then Name (ties)");
var tiedEmployees = new[]
{
    new Employee("Zaid", 60000),
    new Employee("Amal", 60000),
    new Employee("Yara", 50000),
};
SortingTwo<Employee>.Sort(tiedEmployees, (a, b) =>
{
    int salaryCompare = a.Salary.CompareTo(b.Salary);
    return salaryCompare != 0 ? salaryCompare : string.Compare(a.Name, b.Name, StringComparison.Ordinal);
});
foreach (var e in tiedEmployees) Console.WriteLine(e);

// 9) default(T) with GetDefault<T>
Section("9) GetDefault<T> - default values for value vs. reference types");
Console.WriteLine($"default(int) = {SortingAlgorithm<int>.GetDefault<int>()}");
Console.WriteLine($"default(bool) = {SortingAlgorithm<int>.GetDefault<bool>()}");
Console.WriteLine($"default(string) = {SortingAlgorithm<int>.GetDefault<string>() ?? "null"}");

// 10) ICloneable constraint - clone Employee array before sorting
Section("10) Clone Employee[] (ICloneable constraint) before sorting");
var originalEmployees = new[]
{
    new Employee("Faisal", 70000),
    new Employee("Reem", 45000),
};
var clonedEmployees = SortingAlgorithm<Employee>.CloneArray(originalEmployees);
SortingAlgorithm<Employee>.Sort(clonedEmployees);
Console.WriteLine("Original (untouched): " + string.Join(" | ", (object[])originalEmployees));
Console.WriteLine("Cloned + sorted:      " + string.Join(" | ", (object[])clonedEmployees));

// 11) Custom delegate: string -> string transformations
Section("11) Func<string,string> transformations");
var names = new List<string> { "hello", "world", "csharp" };
Console.WriteLine("Uppercase: " + string.Join(", ", DelegateDemos.TransformStrings(names, s => s.ToUpper())));
Console.WriteLine("Reversed:  " + string.Join(", ", DelegateDemos.TransformStrings(names, s => new string(s.Reverse().ToArray()))));

// 12) Delegate: two ints -> int (math operations)
Section("12) Func<int,int,int> math operations");
Console.WriteLine($"Add: {DelegateDemos.ApplyOperation(6, 3, (a, b) => a + b)}");
Console.WriteLine($"Subtract: {DelegateDemos.ApplyOperation(6, 3, (a, b) => a - b)}");
Console.WriteLine($"Multiply: {DelegateDemos.ApplyOperation(6, 3, (a, b) => a * b)}");
Console.WriteLine($"Divide: {DelegateDemos.ApplyOperation(6, 3, (a, b) => a / b)}");

// 13) Generic delegate Transformer<T,R>: list of int -> list of string
Section("13) Generic delegate Transformer<T,R> - int list to string list");
var intList = new List<int> { 1, 2, 3, 4 };
var stringList = DelegateDemos.TransformList<int, string>(intList, n => $"#{n}");
Console.WriteLine(string.Join(", ", stringList));

// 14) Func<int,int>: square each element
Section("14) Func<int,int> - square each element");
Console.WriteLine(string.Join(", ", DelegateDemos.SquareAll(intList)));

// 15) Action<string>: print each string
Section("15) Action<string> - print each string");
DelegateDemos.PrintAll(names, s => Console.WriteLine($"  -> {s}"));

// 16) Predicate<int>: filter even numbers
Section("16) Predicate<int> - filter even numbers");
var mixedNumbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8 };
Console.WriteLine(string.Join(", ", DelegateDemos.FilterEven(mixedNumbers)));

// 17) Anonymous function filtering strings (starts with letter / contains substring)
Section("17) Anonymous-function string filters");
var fruits = new List<string> { "apple", "banana", "avocado", "cherry", "apricot" };
Console.WriteLine("Starts with 'a': " + string.Join(", ", DelegateDemos.FilterWithAnonymousMethod(fruits, delegate (string s) { return s.StartsWith("a"); })));
Console.WriteLine("Contains 'err': " + string.Join(", ", DelegateDemos.FilterWithAnonymousMethod(fruits, delegate (string s) { return s.Contains("err"); })));

// 18) Anonymous function performing a math operation
Section("18) Anonymous function - math operation");
Func<int, int, int> anonymousMultiply = delegate (int a, int b) { return a * b; };
Console.WriteLine($"7 * 8 = {DelegateDemos.ApplyAnonymousMathOp(7, 8, anonymousMultiply)}");

// 19) Lambda expression filtering strings (length > 3 or contains 'e')
Section("19) Lambda-expression string filters");
Console.WriteLine("Length > 3: " + string.Join(", ", DelegateDemos.FilterWithLambda(fruits, s => s.Length > 3)));
Console.WriteLine("Contains 'e': " + string.Join(", ", DelegateDemos.FilterWithLambda(fruits, s => s.Contains('e'))));

// 20) Lambda expression - math on doubles (division, exponentiation)
Section("20) Lambda expression - math on doubles");
Console.WriteLine($"10 / 4 = {DelegateDemos.ApplyLambdaMathOp(10, 4, (a, b) => a / b)}");
Console.WriteLine($"2 ^ 10 = {DelegateDemos.ApplyLambdaMathOp(2, 10, (a, b) => Math.Pow(a, b))}");
