using CSharpExercises.Exercises;

int choice = -1;

while (choice != 0)
{
    Console.Clear();
    Console.WriteLine("=== C# Practice Exercises ===");
    Console.WriteLine(" 1  - Divide two integers (DivideByZeroException + finally)");
    Console.WriteLine(" 2  - Defensive input with TryParse (positive X, Y > 1)");
    Console.WriteLine(" 3  - Nullable int, ?? operator, HasValue vs Value");
    Console.WriteLine(" 4  - Array index out of bounds");
    Console.WriteLine(" 5  - 3x3 array: row/column sums");
    Console.WriteLine(" 6  - Jagged array (3 rows, varying sizes)");
    Console.WriteLine(" 7  - Nullable reference types (string?, null-forgiveness !)");
    Console.WriteLine(" 8  - Boxing and unboxing");
    Console.WriteLine(" 9  - SumAndMultiply using out parameters");
    Console.WriteLine("10  - Optional parameter + named parameters");
    Console.WriteLine("11  - Null-conditional operator (?.) with array");
    Console.WriteLine("12  - Switch expression for day of week");
    Console.WriteLine("13  - SumArray using params");
    Console.WriteLine("--- Part 2 ---");
    Console.WriteLine("14  - Print numbers in a range (1 to N)");
    Console.WriteLine("15  - Multiplication table (up to 12x)");
    Console.WriteLine("16  - List even numbers (1 to N)");
    Console.WriteLine("17  - Compute exponentiation (base^exponent)");
    Console.WriteLine("18  - Reverse a text string");
    Console.WriteLine("19  - Reverse an integer's digits");
    Console.WriteLine("20  - Longest distance between matching elements");
    Console.WriteLine("21  - Reverse words in a sentence");
    Console.WriteLine(" 0  - Exit");
    Console.Write("\nChoose an exercise: ");

    if (!int.TryParse(Console.ReadLine(), out choice))
    {
        choice = -1;
        continue;
    }

    Console.WriteLine();

    switch (choice)
    {
        case 1: Exercise01_DivideException.Run(); break;
        case 2: Exercise02_DefensiveInput.Run(); break;
        case 3: Exercise03_NullableInt.Run(); break;
        case 4: Exercise04_ArrayBounds.Run(); break;
        case 5: Exercise05_Matrix3x3.Run(); break;
        case 6: Exercise06_JaggedArray.Run(); break;
        case 7: Exercise07_NullableReferenceTypes.Run(); break;
        case 8: Exercise08_BoxingUnboxing.Run(); break;
        case 9: Exercise09_OutParameters.Run(); break;
        case 10: Exercise10_OptionalNamedParams.Run(); break;
        case 11: Exercise11_NullConditional.Run(); break;
        case 12: Exercise12_SwitchExpression.Run(); break;
        case 13: Exercise13_ParamsArray.Run(); break;
        case 14: Exercise14_PrintRange.Run(); break;
        case 15: Exercise15_MultiplicationTable.Run(); break;
        case 16: Exercise16_EvenNumbers.Run(); break;
        case 17: Exercise17_Exponentiation.Run(); break;
        case 18: Exercise18_ReverseString.Run(); break;
        case 19: Exercise19_ReverseInteger.Run(); break;
        case 20: Exercise20_LongestDistance.Run(); break;
        case 21: Exercise21_ReverseWords.Run(); break;
        case 0: break;
        default: Console.WriteLine("Invalid choice."); break;
    }

    if (choice != 0)
    {
        Console.WriteLine("\nPress any key to return to the menu...");
        Console.ReadKey();
    }
}
