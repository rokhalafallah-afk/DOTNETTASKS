namespace CSharpExercises.Exercises;

// Q: How does the null-conditional (?.) operator prevent NullReferenceException?
// Normally, calling a member or indexer on a null reference throws a
// NullReferenceException. The ?. operator first checks whether the left-hand
// operand is null: if it is, the expression short-circuits and evaluates to
// null instead of throwing; if not, the member access proceeds normally.
public static class Exercise11_NullConditional
{
    public static void Run()
    {
        int[]? numbers = null;

        // Null-conditional operator (?.) — safely accesses Length
        // without throwing if numbers is null.
        int? length = numbers?.Length;
        Console.WriteLine(length.HasValue
            ? $"Array length: {length.Value}"
            : "Array is null — no length to report.");

        // Now assign an actual array and try again
        numbers = new int[] { 1, 2, 3, 4 };
        int? length2 = numbers?.Length;
        Console.WriteLine($"Array length: {length2 ?? 0}");

        // Combine ?. with ?[] to safely access an element
        int? firstElement = numbers?[0];
        Console.WriteLine($"First element: {firstElement}");
    }
}
