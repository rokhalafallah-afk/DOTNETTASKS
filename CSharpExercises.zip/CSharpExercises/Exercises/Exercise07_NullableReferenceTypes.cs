namespace CSharpExercises.Exercises;

// Q: What is the purpose of nullable reference types in C#?
// Nullable reference types let the compiler track and warn about possible
// null-reference usage at compile time rather than only at runtime. By
// distinguishing string (expected non-null) from string? (may be null), the
// compiler flags places where a possibly-null value is dereferenced without a
// check, catching NullReferenceException bugs before the code ever runs.
public static class Exercise07_NullableReferenceTypes
{
    public static void Run()
    {
        string? nullableName = null;

        Console.Write("Do you want to provide a name? (y/n): ");
        string answer = Console.ReadLine() ?? "n";

        if (answer.ToLower() == "y")
        {
            Console.Write("Enter your name: ");
            nullableName = Console.ReadLine();
        }

        // Null-forgiveness operator (!): tells the compiler
        // "trust me, this is not null" — use only when you are certain.
        if (nullableName != null)
        {
            string confirmedName = nullableName!;
            Console.WriteLine($"Hello, {confirmedName}!");
        }
        else
        {
            Console.WriteLine("No name was provided.");
        }
    }
}
