namespace CSharpExercises.Exercises;

// Prints all numbers from 1 to a user-provided positive integer.
public static class Exercise14_PrintRange
{
    public static void Run()
    {
        int n = ReadPositiveInt("Enter a positive integer: ");

        List<string> numbers = new();
        for (int i = 1; i <= n; i++)
        {
            numbers.Add(i.ToString());
        }

        Console.WriteLine(string.Join(", ", numbers));
    }

    private static int ReadPositiveInt(string prompt)
    {
        int value;
        while (true)
        {
            Console.Write(prompt);
            if (int.TryParse(Console.ReadLine(), out value) && value > 0)
                return value;

            Console.WriteLine("Invalid input. Please enter a positive integer.");
        }
    }
}
