namespace CSharpExercises.Exercises;

// Q: Why is it necessary to check array bounds before accessing elements?
// Arrays in C# have a fixed length, and accessing an index outside 0 to
// Length - 1 throws an IndexOutOfRangeException, crashing the program if
// unhandled. Checking bounds beforehand prevents runtime crashes, avoids
// relying on exceptions for normal control flow, and produces more
// predictable, user-friendly behavior.
public static class Exercise04_ArrayBounds
{
    public static void Run()
    {
        int[] numbers = { 10, 20, 30, 40, 50 };

        try
        {
            Console.Write("Enter an index to access (0-4): ");
            int index = int.Parse(Console.ReadLine()!);

            Console.WriteLine($"Value at index {index}: {numbers[index]}");
        }
        catch (IndexOutOfRangeException)
        {
            Console.WriteLine("Error: Index is out of the bounds of the array.");
        }
        catch (FormatException)
        {
            Console.WriteLine("Error: Please enter a valid number.");
        }
    }
}
