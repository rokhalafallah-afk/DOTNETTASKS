namespace CSharpExercises.Exercises;

// Q: How is the GetLength(dimension) method used in multi-dimensional arrays?
// GetLength(int dimension) returns the number of elements along a specific
// dimension of a multi-dimensional array. For a 2D array, GetLength(0) gives
// the number of rows and GetLength(1) gives the number of columns. It's the
// safe, dynamic way to bound loops instead of hardcoding sizes.
public static class Exercise05_Matrix3x3
{
    public static void Run()
    {
        int[,] matrix = new int[3, 3];

        for (int i = 0; i < matrix.GetLength(0); i++)
        {
            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                Console.Write($"Enter value for [{i},{j}]: ");
                matrix[i, j] = int.Parse(Console.ReadLine()!);
            }
        }

        for (int i = 0; i < matrix.GetLength(0); i++)
        {
            int rowSum = 0;
            for (int j = 0; j < matrix.GetLength(1); j++)
                rowSum += matrix[i, j];
            Console.WriteLine($"Sum of row {i}: {rowSum}");
        }

        for (int j = 0; j < matrix.GetLength(1); j++)
        {
            int colSum = 0;
            for (int i = 0; i < matrix.GetLength(0); i++)
                colSum += matrix[i, j];
            Console.WriteLine($"Sum of column {j}: {colSum}");
        }
    }
}
