namespace CSharpExercises.Exercises;

// Prints all even numbers between 1 and a user-provided number.
public static class Exercise16_EvenNumbers
{
    public static void Run()
    {
        Console.Write("Enter a number: ");
        int n = int.Parse(Console.ReadLine()!);

        List<string> evens = new();
        for (int i = 1; i <= n; i++)
        {
            if (i % 2 == 0)
                evens.Add(i.ToString());
        }

        Console.WriteLine(string.Join(", ", evens));
    }
}
