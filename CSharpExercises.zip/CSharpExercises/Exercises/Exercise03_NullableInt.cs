namespace CSharpExercises.Exercises;

// Q: What exception occurs when trying to access .Value on a null Nullable<T>?
// An InvalidOperationException is thrown, with a message like "Nullable object
// must have a value." Always check .HasValue (or use ??, pattern matching, or
// ?.) before accessing .Value directly.
public static class Exercise03_NullableInt
{
    public static void Run()
    {
        int? nullableInt = null;

        // Null-coalescing operator: assign default if null
        int result = nullableInt ?? 100;
        Console.WriteLine($"Result using ?? operator: {result}");

        // Demonstrating HasValue
        if (nullableInt.HasValue)
        {
            Console.WriteLine($"Value is: {nullableInt.Value}");
        }
        else
        {
            Console.WriteLine("nullableInt has no value (HasValue = false).");
        }

        // Assign a real value and show Value works safely now
        nullableInt = 42;
        if (nullableInt.HasValue)
        {
            Console.WriteLine($"Now Value is: {nullableInt.Value}");
        }

        // Unsafe access example (would throw InvalidOperationException if null):
        // int crash = nullableInt.Value; // only safe because we checked HasValue first
    }
}
