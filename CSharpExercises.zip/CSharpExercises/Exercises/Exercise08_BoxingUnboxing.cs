namespace CSharpExercises.Exercises;

// Q: What is the performance impact of boxing and unboxing in C#?
// Boxing allocates a new object on the managed heap to wrap the value type and
// copies the value into it; unboxing copies the value back out and requires a
// type check/cast. Both add CPU overhead (allocation, copying, eventual GC)
// compared to working with the value type directly on the stack. In
// performance-sensitive code, frequent boxing/unboxing can noticeably hurt
// performance — generics (List<int>) avoid this entirely.
public static class Exercise08_BoxingUnboxing
{
    public static void Run()
    {
        // Boxing: value type -> object
        int originalValue = 123;
        object boxedValue = originalValue;
        Console.WriteLine($"Boxed value: {boxedValue}");

        // Unboxing: object -> value type
        int unboxedValue = (int)boxedValue;
        Console.WriteLine($"Unboxed value: {unboxedValue}");

        // Invalid unboxing example
        try
        {
            double invalidUnbox = (double)boxedValue; // boxedValue is actually an int
            Console.WriteLine(invalidUnbox);
        }
        catch (InvalidCastException)
        {
            Console.WriteLine("Error: Invalid cast — boxedValue is not a double.");
        }
    }
}
