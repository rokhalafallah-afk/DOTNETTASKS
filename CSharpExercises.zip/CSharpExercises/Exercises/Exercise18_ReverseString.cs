namespace CSharpExercises.Exercises;

// Reverses a user-entered string.
public static class Exercise18_ReverseString
{
    public static void Run()
    {
        Console.Write("Enter a string: ");
        string input = Console.ReadLine() ?? "";

        char[] chars = input.ToCharArray();
        Array.Reverse(chars);
        string reversed = new string(chars);

        Console.WriteLine($"Reversed: {reversed}");
    }
}
