namespace CSharpExercises.Exercises;

// Reverses the digits of an integer entered by the user.
public static class Exercise19_ReverseInteger
{
    public static void Run()
    {
        Console.Write("Enter an integer: ");
        int n = int.Parse(Console.ReadLine()!);

        int original = n;
        bool isNegative = n < 0;
        n = Math.Abs(n);

        int reversed = 0;
        while (n > 0)
        {
            int digit = n % 10;
            reversed = reversed * 10 + digit;
            n /= 10;
        }

        if (isNegative)
            reversed = -reversed;

        Console.WriteLine($"Reversed: {reversed}");
    }
}
