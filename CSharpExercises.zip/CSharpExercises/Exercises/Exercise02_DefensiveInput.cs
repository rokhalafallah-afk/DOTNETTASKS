namespace CSharpExercises.Exercises;

// Q: How does int.TryParse() improve program robustness compared to int.Parse()?
// int.Parse() throws a FormatException (or OverflowException) if the input isn't
// a valid integer, which crashes the program unless wrapped in a try/catch.
// int.TryParse() instead returns a bool indicating success/failure and never
// throws for bad input — cheaper (no exception overhead) and lets you loop and
// re-prompt the user cleanly without exception-handling logic in the control flow.
public static class Exercise02_DefensiveInput
{
    public static void Run()
    {
        int x = ReadPositiveInt("Enter X (positive integer): ");
        int y;

        do
        {
            y = ReadPositiveInt("Enter Y (must be greater than 1): ");
            if (y <= 1)
                Console.WriteLine("Y must be greater than 1. Try again.");
        } while (y <= 1);

        Console.WriteLine($"X = {x}, Y = {y}");
    }

    private static int ReadPositiveInt(string prompt)
    {
        int value;
        while (true)
        {
            Console.Write(prompt);
            string? input = Console.ReadLine();

            if (int.TryParse(input, out value) && value > 0)
                return value;

            Console.WriteLine("Invalid input. Please enter a positive integer.");
        }
    }
}
