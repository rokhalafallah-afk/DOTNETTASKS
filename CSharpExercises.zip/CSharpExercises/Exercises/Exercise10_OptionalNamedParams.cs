namespace CSharpExercises.Exercises;

// Q: Why must optional parameters always appear at the end of a method's
// parameter list?
// The compiler matches positional arguments left-to-right by position. If an
// optional parameter came before a required one, the compiler couldn't tell
// whether an omitted argument should "skip" the optional parameter or shift
// the following arguments. Required-then-optional ordering keeps positional
// calls unambiguous (named arguments can still be given in any order).
public static class Exercise10_OptionalNamedParams
{
    public static void Run()
    {
        // Uses the default value (5)
        PrintRepeated("Hello");

        // Overrides the default, using a named parameter
        PrintRepeated(text: "Hi there", times: 3);

        // Named parameters can also be passed in any order
        PrintRepeated(times: 2, text: "Named order doesn't matter");
    }

    private static void PrintRepeated(string text, int times = 5)
    {
        for (int i = 0; i < times; i++)
        {
            Console.WriteLine(text);
        }
    }
}
