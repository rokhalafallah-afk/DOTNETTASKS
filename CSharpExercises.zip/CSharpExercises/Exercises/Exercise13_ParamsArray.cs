namespace CSharpExercises.Exercises;

// Note: params lets a method accept a variable number of arguments of the
// same type. Callers can pass a comma-separated list, an actual array, or
// nothing at all — the compiler packages loose arguments into an array
// automatically. A method can have only one params parameter, and it must be
// the last parameter in the list.
public static class Exercise13_ParamsArray
{
    public static void Run()
    {
        // Calling with individual values
        int result1 = SumArray(1, 2, 3, 4, 5);
        Console.WriteLine($"Sum of individual values: {result1}");

        // Calling with an actual array
        int[] myArray = { 10, 20, 30 };
        int result2 = SumArray(myArray);
        Console.WriteLine($"Sum of array: {result2}");

        // Calling with no arguments at all (valid with params)
        int result3 = SumArray();
        Console.WriteLine($"Sum of nothing: {result3}");
    }

    private static int SumArray(params int[] numbers)
    {
        int sum = 0;
        foreach (int n in numbers)
        {
            sum += n;
        }
        return sum;
    }
}
