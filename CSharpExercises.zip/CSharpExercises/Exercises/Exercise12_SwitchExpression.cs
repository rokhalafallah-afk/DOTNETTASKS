namespace CSharpExercises.Exercises;

// Q: When is a switch expression preferred over a traditional if statement?
// A switch expression is preferred when mapping a single value to one of
// several discrete outcomes based on equality or pattern matching — it's more
// concise than a long if/else if chain, is itself an expression that produces
// a value directly, and the compiler can warn if a switch isn't exhaustive.
// A traditional if statement suits complex boolean conditions or overlapping
// ranges better.
public static class Exercise12_SwitchExpression
{
    public static void Run()
    {
        Console.Write("Enter a day of the week: ");
        string? day = Console.ReadLine();

        int dayNumber = day?.Trim().ToLower() switch
        {
            "monday" => 1,
            "tuesday" => 2,
            "wednesday" => 3,
            "thursday" => 4,
            "friday" => 5,
            "saturday" => 6,
            "sunday" => 7,
            _ => -1 // unrecognized input
        };

        if (dayNumber == -1)
            Console.WriteLine("Not a recognized day of the week.");
        else
            Console.WriteLine($"{day} is day number {dayNumber} of the week.");
    }
}
