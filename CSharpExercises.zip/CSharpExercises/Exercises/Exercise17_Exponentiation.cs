namespace CSharpExercises.Exercises;

// Raises the first number to the power of the second (computed manually
// with a loop, without using Math.Pow, to show the underlying logic).
public static class Exercise17_Exponentiation
{
    public static void Run()
    {
        Console.Write("Enter the base: ");
        int baseNumber = int.Parse(Console.ReadLine()!);

        Console.Write("Enter the exponent: ");
        int exponent = int.Parse(Console.ReadLine()!);

        long result = 1;
        for (int i = 0; i < exponent; i++)
        {
            result *= baseNumber;
        }

        Console.WriteLine($"{baseNumber}^{exponent} = {result}");

        // Equivalent built-in approach:
        // double result2 = Math.Pow(baseNumber, exponent);
    }
}
