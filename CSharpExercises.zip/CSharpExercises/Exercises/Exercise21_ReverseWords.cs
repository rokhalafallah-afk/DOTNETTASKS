namespace CSharpExercises.Exercises;

// Reverses the order of space-separated words in a sentence, using Split.
public static class Exercise21_ReverseWords
{
    public static void Run()
    {
        Console.Write("Enter a sentence: ");
        string sentence = Console.ReadLine() ?? "";

        string[] words = sentence.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        Array.Reverse(words);

        Console.WriteLine(string.Join(" ", words));
    }
}
