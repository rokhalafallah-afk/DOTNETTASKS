namespace CSharpExercises.Exercises;

// Q: What is the purpose of the finally block?
// The finally block always runs after the try/catch, whether an exception
// was thrown or not, and even if the exception wasn't caught. It's used
// for cleanup code that must execute regardless of outcome — closing
// files, releasing resources, database connections, or (as here) simply
// signaling that the operation has finished.
public static class Exercise01_DivideException
{
    public static void Run()
    {
        try
        {
            Console.Write("Enter first integer: ");
            int a = int.Parse(Console.ReadLine()!);

            Console.Write("Enter second integer: ");
            int b = int.Parse(Console.ReadLine()!);

            int result = a / b;
            Console.WriteLine($"Result: {result}");
        }
        catch (DivideByZeroException)
        {
            Console.WriteLine("Error: You cannot divide by zero.");
        }
        catch (FormatException)
        {
            Console.WriteLine("Error: Please enter valid integers.");
        }
        finally
        {
            Console.WriteLine("Operation complete.");
        }
    }
}
