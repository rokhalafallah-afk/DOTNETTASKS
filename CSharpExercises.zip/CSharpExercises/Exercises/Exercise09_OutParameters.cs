namespace CSharpExercises.Exercises;

// Q: Why must out parameters be initialized inside the method?
// The out keyword tells the compiler the caller doesn't need to initialize the
// argument before the call — the method is responsible for assigning it a
// definite value before returning. The compiler enforces this: it's a
// compile-time error if a method with an out parameter returns without
// assigning that parameter on every code path.
public static class Exercise09_OutParameters
{
    public static void Run()
    {
        int x = 6, y = 7;
        SumAndMultiply(x, y, out int sum, out int product);

        Console.WriteLine($"Sum: {sum}");
        Console.WriteLine($"Product: {product}");
    }

    private static void SumAndMultiply(int a, int b, out int sum, out int product)
    {
        sum = a + b;
        product = a * b;
    }
}
