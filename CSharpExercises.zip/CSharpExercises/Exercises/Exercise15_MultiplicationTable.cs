namespace CSharpExercises.Exercises;

// Prints the multiplication table for a number, up to 12 times.
public static class Exercise15_MultiplicationTable
{
    public static void Run()
    {
        Console.Write("Enter an integer: ");
        int n = int.Parse(Console.ReadLine()!);

        List<string> results = new();
        for (int i = 1; i <= 12; i++)
        {
            results.Add((n * i).ToString());
        }

        Console.WriteLine(string.Join(", ", results));
    }
}
