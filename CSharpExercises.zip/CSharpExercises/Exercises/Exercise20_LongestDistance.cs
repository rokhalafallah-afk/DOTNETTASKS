namespace CSharpExercises.Exercises;

// Finds the longest distance (number of cells strictly between two indices)
// between two occurrences of the same value in an array.
// Example: 7,0,0,0,0,5,6,7,5,0,7,5,3
//   The first 7 is at index 0, the last 7 is at index 10.
//   Distance = 10 - 0 - 1 = 9 cells between them.
public static class Exercise20_LongestDistance
{
    public static void Run()
    {
        Console.Write("Enter the number of elements in the array: ");
        int n = int.Parse(Console.ReadLine()!);

        int[] array = new int[n];
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Enter element {i}: ");
            array[i] = int.Parse(Console.ReadLine()!);
        }

        // Remember the first index at which each value was seen.
        Dictionary<int, int> firstIndex = new();
        int maxDistance = 0;
        int bestValue = 0;
        int bestStart = -1, bestEnd = -1;

        for (int i = 0; i < array.Length; i++)
        {
            int value = array[i];

            if (firstIndex.TryGetValue(value, out int firstSeenIndex))
            {
                int distance = i - firstSeenIndex - 1; // cells strictly between them
                if (distance > maxDistance)
                {
                    maxDistance = distance;
                    bestValue = value;
                    bestStart = firstSeenIndex;
                    bestEnd = i;
                }
            }
            else
            {
                firstIndex[value] = i;
            }
        }

        if (bestStart == -1)
        {
            Console.WriteLine("No two identical elements were found in the array.");
        }
        else
        {
            Console.WriteLine(
                $"Longest distance is {maxDistance} cells, between value {bestValue} " +
                $"at index {bestStart} and index {bestEnd}.");
        }
    }
}
