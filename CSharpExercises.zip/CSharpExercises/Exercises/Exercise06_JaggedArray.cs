namespace CSharpExercises.Exercises;

// Q: How does memory allocation differ between jagged arrays and rectangular arrays?
// A rectangular array (int[3,3]) is a single contiguous block of memory with a
// fixed size in every dimension. A jagged array (int[][]) is an array of
// references, where each row is its own independently allocated array — rows
// can have different lengths and live in different memory locations. This makes
// jagged arrays more flexible but adds a level of indirection per row access.
public static class Exercise06_JaggedArray
{
    public static void Run()
    {
        int[][] jaggedArray = new int[3][];

        for (int i = 0; i < jaggedArray.Length; i++)
        {
            Console.Write($"Enter number of elements for row {i}: ");
            int size = int.Parse(Console.ReadLine()!);
            jaggedArray[i] = new int[size];

            for (int j = 0; j < size; j++)
            {
                Console.Write($"  Row {i}, element {j}: ");
                jaggedArray[i][j] = int.Parse(Console.ReadLine()!);
            }
        }

        Console.WriteLine("\nJagged array contents:");
        for (int i = 0; i < jaggedArray.Length; i++)
        {
            Console.Write($"Row {i}: ");
            foreach (int value in jaggedArray[i])
            {
                Console.Write(value + " ");
            }
            Console.WriteLine();
        }
    }
}
