namespace OOPPractice.Products;

public class Product : IComparable<Product>
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }

    public Product(int id, string name, decimal price)
    {
        Id = id;
        Name = name;
        Price = price;
    }

    // Defines Product's natural sort order (by Price), so any framework
    // sorting method (Array.Sort, List<T>.Sort, etc.) can order Products.
    public int CompareTo(Product? other)
    {
        if (other is null) return 1;
        return Price.CompareTo(other.Price);
    }

    public override string ToString() => $"{Name} (${Price})";
}
