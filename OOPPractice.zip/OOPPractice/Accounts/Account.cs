namespace OOPPractice.Accounts;

public struct Account
{
    private int accountId;
    private string accountHolder;
    private decimal balance;

    public Account(int accountId, string accountHolder, decimal balance)
    {
        this.accountId = accountId;
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

    public int AccountId => accountId;
    public string AccountHolder => accountHolder;

    public decimal Balance
    {
        get => balance;
        private set => balance = value;
    }

    public void Deposit(decimal amount)
    {
        if (amount > 0) Balance += amount;
    }
}
