using OOPPractice.Accounts;
using OOPPractice.Books;
using OOPPractice.Logging;
using OOPPractice.Products;
using OOPPractice.Robots;
using OOPPractice.Shapes;
using OOPPractice.Students;
using OOPPractice.Vehicles;

void Header(string title)
{
    Console.WriteLine();
    Console.WriteLine(new string('=', 60));
    Console.WriteLine(title);
    Console.WriteLine(new string('=', 60));
}

// 1. IVehicle -> Car / Bike
Header("1. IVehicle Interface (Car, Bike)");
IVehicle[] vehicles = { new Car(), new Bike() };
foreach (IVehicle v in vehicles)
{
    v.StartEngine();
    v.StopEngine();
}

// 2. Abstract Shape -> Rectangle / Circle
Header("2. Abstract Class Shape (Rectangle, Circle)");
Shape[] shapes = { new Rectangle(4, 5), new Circle(3) };
foreach (Shape s in shapes)
{
    s.Display();
}

// 3. Product : IComparable<Product>
Header("3. Product implementing IComparable<Product>");
Product[] products =
{
    new Product(1, "Keyboard", 45.00m),
    new Product(2, "Monitor", 199.99m),
    new Product(3, "Mouse", 15.50m)
};
Array.Sort(products);
foreach (var p in products) Console.WriteLine(p);

// 4. Student copy constructor: shallow vs deep copy
Header("4. Student — Shallow vs. Deep Copy");
var original = new Student(1, "Alice", 90, new Address("Cairo"));

var shallow = original.ShallowCopy();
var deep = new Student(original); // deep copy via copy constructor

shallow.StudentAddress.City = "Alexandria"; // shared Address -> affects original too
Console.WriteLine($"Original city after editing SHALLOW copy: {original.StudentAddress.City}");

deep.StudentAddress.City = "Giza"; // independent Address -> original untouched
Console.WriteLine($"Original city after editing DEEP copy:    {original.StudentAddress.City}");

// 5. IWalkable explicit implementation on Robot
Header("5. IWalkable — Explicit Interface Implementation (Robot)");
Robot r = new Robot();
r.Walk();                 // Robot's own Walk()
IWalkable walkable = r;
walkable.Walk();          // explicit IWalkable.Walk()

// 6. Account struct encapsulation
Header("6. Account Struct — Encapsulation");
Account acc = new Account(101, "Sara", 500m);
acc.Deposit(150m);
Console.WriteLine($"{acc.AccountHolder}'s balance: {acc.Balance}");

// 7. ILogger default interface implementation
Header("7. ILogger — Default Interface Implementation");
ILogger consoleLogger = new ConsoleLogger();
consoleLogger.Log("Custom log message");   // overridden

ILogger silentLogger = new SilentLogger();
silentLogger.Log("Fallback log message");  // uses ILogger's default body

// 8. Book constructor overloading
Header("8. Book — Constructor Overloading");
Book b1 = new Book();
Book b2 = new Book("1984");
Book b3 = new Book("Dune", "Frank Herbert");
Console.WriteLine(b1);
Console.WriteLine(b2);
Console.WriteLine(b3);

Console.WriteLine();
Console.WriteLine(new string('=', 60));
Console.WriteLine("Done.");
