namespace OOPPractice.Robots;

public interface IWalkable
{
    void Walk();
}
