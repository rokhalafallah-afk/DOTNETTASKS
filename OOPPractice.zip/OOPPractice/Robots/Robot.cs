namespace OOPPractice.Robots;

public class Robot : IWalkable
{
    // Robot's own "primary" Walk behavior — reachable via a Robot reference.
    public void Walk()
    {
        Console.WriteLine("Robot moves using wheels/treads.");
    }

    // Explicit implementation: only reachable via an IWalkable reference.
    // Lets the class give the interface method a different body than
    // its own public Walk(), avoiding a naming/behavior clash.
    void IWalkable.Walk()
    {
        Console.WriteLine("Robot performs a bipedal walking simulation (IWalkable mode).");
    }
}
