namespace OOPPractice.Logging;

public interface ILogger
{
    // Default interface implementation (C# 8+): existing/new implementers
    // that don't override this still compile and get working behavior.
    void Log(string message)
    {
        Console.WriteLine($"[Default Log]: {message}");
    }
}
