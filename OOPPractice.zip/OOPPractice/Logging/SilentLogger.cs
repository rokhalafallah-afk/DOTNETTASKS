namespace OOPPractice.Logging;

// Does not override Log() -> falls back to ILogger's default implementation.
public class SilentLogger : ILogger
{
}
