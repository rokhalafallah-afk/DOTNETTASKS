namespace OOPPractice.Shapes;

public class Circle : Shape
{
    private readonly double radius;

    public Circle(double radius)
    {
        this.radius = radius;
    }

    public override double GetArea() => Math.PI * radius * radius;
}
