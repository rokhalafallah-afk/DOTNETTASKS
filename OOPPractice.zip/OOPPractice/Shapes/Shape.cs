namespace OOPPractice.Shapes;

/// <summary>
/// Abstract base providing a shared, concrete Display() implementation
/// while forcing subclasses to define their own area calculation.
/// </summary>
public abstract class Shape
{
    public abstract double GetArea();

    public void Display()
    {
        Console.WriteLine($"The area is: {GetArea():F2}");
    }
}
