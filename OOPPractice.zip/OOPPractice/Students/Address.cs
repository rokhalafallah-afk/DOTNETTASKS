namespace OOPPractice.Students;

public class Address
{
    public string City { get; set; }

    public Address(string city)
    {
        City = city;
    }
}
