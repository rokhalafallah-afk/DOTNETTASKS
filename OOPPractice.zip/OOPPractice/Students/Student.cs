namespace OOPPractice.Students;

public class Student
{
    public int Id { get; set; }
    public string Name { get; set; }
    public double Grade { get; set; }
    public Address StudentAddress { get; set; }

    public Student(int id, string name, double grade, Address address)
    {
        Id = id;
        Name = name;
        Grade = grade;
        StudentAddress = address;
    }

    // Shallow copy: the new Student shares the SAME Address reference.
    public Student ShallowCopy()
    {
        return new Student(Id, Name, Grade, StudentAddress);
    }

    // Copy constructor: performs a DEEP copy by creating a brand-new
    // Address instance, so the copy is fully independent of the original.
    public Student(Student other)
    {
        Id = other.Id;
        Name = other.Name;
        Grade = other.Grade;
        StudentAddress = new Address(other.StudentAddress.City);
    }
}
