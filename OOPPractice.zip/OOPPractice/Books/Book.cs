namespace OOPPractice.Books;

public class Book
{
    public string Title { get; set; }
    public string Author { get; set; }

    public Book() : this("Untitled", "Unknown")
    {
    }

    public Book(string title) : this(title, "Unknown")
    {
    }

    public Book(string title, string author)
    {
        Title = title;
        Author = author;
    }

    public override string ToString() => $"\"{Title}\" by {Author}";
}
