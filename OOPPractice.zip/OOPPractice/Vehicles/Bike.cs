namespace OOPPractice.Vehicles;

public class Bike : IVehicle
{
    public void StartEngine() => Console.WriteLine("Bike engine started.");
    public void StopEngine() => Console.WriteLine("Bike engine stopped.");
}
