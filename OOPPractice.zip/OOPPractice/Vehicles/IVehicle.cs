namespace OOPPractice.Vehicles;

/// <summary>
/// Contract for anything that can be started and stopped.
/// Consumers depend on this abstraction, not on Car/Bike directly.
/// </summary>
public interface IVehicle
{
    void StartEngine();
    void StopEngine();
}
