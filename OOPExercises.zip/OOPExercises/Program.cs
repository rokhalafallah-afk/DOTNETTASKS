using OOPExercises.Exercises;

int choice = -1;

while (choice != 0)
{
    Console.Clear();
    Console.WriteLine("=== OOP Practice Exercises ===");
    Console.WriteLine(" 1  - Car: constructor overloading");
    Console.WriteLine(" 2  - Calculator: method overloading (Sum)");
    Console.WriteLine(" 3  - Parent/Child: constructor chaining");
    Console.WriteLine(" 4  - Parent/Child: 'new' vs 'override'");
    Console.WriteLine(" 5  - Parent/Child: overriding ToString()");
    Console.WriteLine(" 6  - IShape interface + Rectangle");
    Console.WriteLine(" 7  - Interface default implementation + Circle");
    Console.WriteLine(" 8  - IMovable interface + Car, called via interface reference");
    Console.WriteLine(" 9  - Multiple interfaces (IReadable, IWritable) + File");
    Console.WriteLine("10  - Abstract class Shape (virtual + abstract methods)");
    Console.WriteLine(" 0  - Exit");
    Console.Write("\nChoose an exercise: ");

    if (!int.TryParse(Console.ReadLine(), out choice))
    {
        choice = -1;
        continue;
    }

    Console.WriteLine();

    switch (choice)
    {
        case 1: Exercise01_CarConstructors.Run(); break;
        case 2: Exercise02_CalculatorOverload.Run(); break;
        case 3: Exercise03_ConstructorChaining.Run(); break;
        case 4: Exercise04_NewVsOverride.Run(); break;
        case 5: Exercise05_ToStringOverride.Run(); break;
        case 6: Exercise06_IShapeInterface.Run(); break;
        case 7: Exercise07_DefaultInterfaceImplementation.Run(); break;
        case 8: Exercise08_IMovableInterface.Run(); break;
        case 9: Exercise09_MultipleInterfaces.Run(); break;
        case 10: Exercise10_AbstractVsVirtual.Run(); break;
        case 0: break;
        default: Console.WriteLine("Invalid choice."); break;
    }

    if (choice != 0)
    {
        Console.WriteLine("\nPress any key to return to the menu...");
        Console.ReadKey();
    }
}
