namespace OOPExercises.Exercises;

// Q: What is the difference between a virtual method and an abstract method
// in C#?
// A 'virtual' method has a real, default implementation in the base class;
// derived classes MAY override it if they want different behavior, but
// aren't required to -- calling it on a derived instance that doesn't
// override it just runs the base implementation. An 'abstract' method has NO
// implementation at all in the base class (just a signature) and can only
// exist inside an abstract class; every concrete (non-abstract) derived
// class is REQUIRED to override and implement it, or the code won't compile.
// In short: virtual = optional override with a working default; abstract =
// mandatory override with no default.
public static class Exercise10_AbstractVsVirtual
{
    public abstract class Shape
    {
        // Virtual: has a default implementation, override is optional.
        public virtual void Draw()
        {
            Console.WriteLine("Drawing Shape");
        }

        // Abstract: no implementation here; every derived class MUST provide one.
        public abstract double CalculateArea();
    }

    public class Rectangle : Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public override void Draw()
        {
            Console.WriteLine($"Drawing Rectangle ({Width}x{Height})");
        }

        public override double CalculateArea() => Width * Height;
    }

    public static void Run()
    {
        Rectangle rectangle = new(4, 6);
        rectangle.Draw();
        Console.WriteLine($"Area: {rectangle.CalculateArea()}");

        // Note: `Shape shape = new Shape();` would fail to compile --
        // abstract classes can never be instantiated directly.
    }
}
