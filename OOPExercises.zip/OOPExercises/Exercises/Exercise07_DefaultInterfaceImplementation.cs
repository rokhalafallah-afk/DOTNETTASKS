namespace OOPExercises.Exercises;

// Q: What are the benefits of default implementations in interfaces
// (introduced in C# 8.0)?
// Default interface methods let you add a new method to an interface with a
// built-in implementation, without breaking every existing class that
// already implements that interface — those classes simply inherit the
// default behavior automatically instead of failing to compile. This makes
// interfaces easier to evolve over time (especially useful for library/API
// authors), reduces boilerplate for implementers who are happy with the
// default logic, and lets a class still override the default with its own
// version whenever it needs custom behavior.
public static class Exercise07_DefaultInterfaceImplementation
{
    public interface IShape
    {
        double Area { get; }
        void Draw();

        // Default implementation: any implementing class gets this for free
        // unless it chooses to override it.
        void PrintDetails()
        {
            Console.WriteLine($"[Default] This shape has an area of {Area}.");
        }
    }

    public class Circle : IShape
    {
        public double Radius { get; set; }

        public Circle(double radius)
        {
            Radius = radius;
        }

        public double Area => Math.PI * Radius * Radius;

        public void Draw()
        {
            Console.WriteLine($"Drawing a circle with radius {Radius}.");
        }

        // Note: Circle does NOT implement PrintDetails() -- it uses IShape's
        // default implementation automatically.
    }

    public static void Run()
    {
        IShape circle = new Circle(3);
        circle.Draw();

        // Default interface members are only callable through an interface-
        // typed reference, not directly off a class-typed variable.
        circle.PrintDetails();
    }
}
