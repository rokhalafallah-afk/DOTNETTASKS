namespace OOPExercises.Exercises;

// Q: How does 'new' differ from 'override' in method overriding?
// 'override' participates in true polymorphism: the method that runs is
// chosen based on the object's ACTUAL runtime type, even when accessed
// through a base-class reference/variable. 'new' instead just hides the base
// member with an unrelated method of the same name/signature — which method
// runs is decided by the COMPILE-TIME (static) type of the reference used to
// call it, not the object's real type. This is demonstrated below: calling
// Product() through a Parent-typed variable gives the Parent's result with
// 'new', but the Child's result with 'override'.
public static class Exercise04_NewVsOverride
{
    // --- Demonstrating 'new' (method hiding) ---
    public class ParentA
    {
        public int X { get; set; } = 4;
        public int Y { get; set; } = 5;

        public int Product() => X * Y;
    }

    public class ChildUsingNew : ParentA
    {
        // 'new' hides ParentA.Product() rather than overriding it.
        public new int Product() => (X * Y) + 100;
    }

    // --- Demonstrating 'override' (true polymorphism) ---
    public class ParentB
    {
        public int X { get; set; } = 4;
        public int Y { get; set; } = 5;

        public virtual int Product() => X * Y;
    }

    public class ChildUsingOverride : ParentB
    {
        public override int Product() => (X * Y) + 100;
    }

    public static void Run()
    {
        Console.WriteLine("-- Using 'new' (method hiding) --");
        ChildUsingNew childNewDirect = new();
        ParentA parentARef = childNewDirect; // upcast to base type

        Console.WriteLine($"Called on Child-typed reference:  {childNewDirect.Product()}");
        Console.WriteLine($"Called on Parent-typed reference: {parentARef.Product()}  <-- uses ParentA's version!");

        Console.WriteLine();
        Console.WriteLine("-- Using 'override' (true polymorphism) --");
        ChildUsingOverride childOverrideDirect = new();
        ParentB parentBRef = childOverrideDirect; // upcast to base type

        Console.WriteLine($"Called on Child-typed reference:  {childOverrideDirect.Product()}");
        Console.WriteLine($"Called on Parent-typed reference: {parentBRef.Product()}  <-- still uses Child's version!");
    }
}
