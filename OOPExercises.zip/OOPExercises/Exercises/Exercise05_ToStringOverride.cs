namespace OOPExercises.Exercises;

// Q: Why is ToString() often overridden in custom classes?
// The default Object.ToString() just returns the type's fully-qualified name
// (e.g. "OOPExercises.Exercises.Parent"), which is rarely useful for
// debugging, logging, or displaying an object to a user. Overriding it lets a
// class provide a meaningful, human-readable representation of its own
// state. It also integrates automatically wherever the runtime implicitly
// calls ToString() — string interpolation, Console.WriteLine(obj),
// debugger watch windows, and so on — so you get useful output everywhere
// without needing a separate custom method.
public static class Exercise05_ToStringOverride
{
    public class Parent
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Parent(int x, int y)
        {
            X = x;
            Y = y;
        }

        public override string ToString() => $"({X}, {Y})";
    }

    public class Child : Parent
    {
        public int Z { get; set; }

        public Child(int x, int y, int z) : base(x, y)
        {
            Z = z;
        }

        public override string ToString() => $"({X}, {Y}, {Z})";
    }

    public static void Run()
    {
        Parent parent = new(1, 2);
        Child child = new(1, 2, 3);

        // Polymorphism: even through a Parent-typed reference, the Child's
        // overridden ToString() still runs, because override uses the
        // object's real runtime type.
        Parent parentRef = child;

        Console.WriteLine($"Parent instance:            {parent}");
        Console.WriteLine($"Child instance:              {child}");
        Console.WriteLine($"Child via Parent reference:  {parentRef}");
    }
}
