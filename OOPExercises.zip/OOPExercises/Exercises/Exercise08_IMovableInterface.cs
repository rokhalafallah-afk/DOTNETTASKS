namespace OOPExercises.Exercises;

// Q: Why is it useful to use an interface reference to access implementing
// class methods?
// Coding against an interface reference (IMovable rather than the concrete
// Car type) decouples your code from any specific implementation. The
// calling code only depends on the CAPABILITY ("this can Move()"), not on
// which concrete class provides it -- so you could swap in a Bicycle or
// Plane class later, or pass different IMovable implementations into the
// same method, without changing that method's code at all. This is the
// foundation of loosely-coupled, testable, and extensible object-oriented
// design (and enables patterns like dependency injection).
public static class Exercise08_IMovableInterface
{
    public interface IMovable
    {
        void Move();
    }

    public class Car : IMovable
    {
        public string Brand { get; set; } = "Generic";

        public void Move()
        {
            Console.WriteLine($"{Brand} car is moving down the road.");
        }
    }

    public static void Run()
    {
        Car car = new() { Brand = "Toyota" };

        // Access the Car object through an IMovable-typed reference.
        IMovable movable = car;
        movable.Move();
    }
}
