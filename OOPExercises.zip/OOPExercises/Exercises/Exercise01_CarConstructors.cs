namespace OOPExercises.Exercises;

// Q: Why does defining a custom constructor suppress the default constructor?
// C# only auto-generates a public parameterless constructor when a class
// defines NO constructors at all. As soon as you write even one constructor
// yourself, the compiler assumes you're taking full control of object
// initialization and stops generating the implicit parameterless one. If you
// still want a parameterless option alongside your other constructors, you
// must declare it explicitly (as Car() does below).
public static class Exercise01_CarConstructors
{
    public class Car
    {
        public int Id { get; set; }
        public string Brand { get; set; } = string.Empty;
        public decimal Price { get; set; }

        // 1. Default constructor
        public Car()
        {
        }

        // 2. Constructor with one parameter
        public Car(int id)
        {
            Id = id;
        }

        // 3. Constructor with two parameters
        public Car(int id, string brand)
        {
            Id = id;
            Brand = brand;
        }

        // 4. Constructor with all three parameters
        public Car(int id, string brand, decimal price)
        {
            Id = id;
            Brand = brand;
            Price = price;
        }

        public override string ToString() => $"Car(Id={Id}, Brand={Brand}, Price={Price:C})";
    }

    public static void Run()
    {
        Car car1 = new();
        Car car2 = new(1);
        Car car3 = new(2, "Toyota");
        Car car4 = new(3, "Tesla", 45000m);

        Console.WriteLine($"Default constructor:        {car1}");
        Console.WriteLine($"Id only:                     {car2}");
        Console.WriteLine($"Id + Brand:                  {car3}");
        Console.WriteLine($"Id + Brand + Price:          {car4}");
    }
}
