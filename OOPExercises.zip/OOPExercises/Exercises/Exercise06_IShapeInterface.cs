namespace OOPExercises.Exercises;

// Q: Why can't you create an instance of an interface directly?
// An interface only declares a contract — method/property signatures with no
// implementation (aside from optional default interface members, covered in
// the next exercise) and no fields to hold state. There's no actual
// executable body or memory layout the runtime could construct an object
// from. You can only instantiate a concrete class that implements the
// interface, providing the real logic; the interface reference then simply
// points at that concrete object.
public static class Exercise06_IShapeInterface
{
    public interface IShape
    {
        double Area { get; }
        void Draw();
    }

    public class Rectangle : IShape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public double Area => Width * Height;

        public void Draw()
        {
            Console.WriteLine($"Drawing a rectangle {Width}x{Height} (Area = {Area}).");
        }
    }

    public static void Run()
    {
        IShape shape = new Rectangle(4, 5);
        shape.Draw();
        Console.WriteLine($"Area via interface reference: {shape.Area}");
    }
}
