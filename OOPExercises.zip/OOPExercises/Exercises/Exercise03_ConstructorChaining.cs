namespace OOPExercises.Exercises;

// Q: What is the purpose of constructor chaining in inheritance?
// Constructor chaining (via base(...)) lets a derived class delegate the
// initialization of inherited fields/properties to the base class's own
// constructor, instead of duplicating that logic. This keeps initialization
// centralized in one place (the base class), respects encapsulation (the
// derived class doesn't need direct access to how X and Y are set), and
// ensures the base part of the object is always fully and correctly
// constructed before the derived class adds its own initialization on top.
public static class Exercise03_ConstructorChaining
{
    public class Parent
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Parent(int x, int y)
        {
            X = x;
            Y = y;
        }
    }

    public class Child : Parent
    {
        public int Z { get; set; }

        // Chains to Parent's constructor using base(...)
        public Child(int x, int y, int z) : base(x, y)
        {
            Z = z;
        }
    }

    public static void Run()
    {
        Child child = new(1, 2, 3);
        Console.WriteLine($"Child -> X={child.X}, Y={child.Y}, Z={child.Z}");
    }
}
