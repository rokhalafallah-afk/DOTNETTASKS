namespace OOPExercises.Exercises;

// Q: How does method overloading improve code readability and reusability?
// Overloading lets multiple methods share one intuitive name (e.g. Sum)
// while handling different parameter types/counts, so callers don't need to
// remember distinct names like SumTwoInts, SumThreeInts, SumTwoDoubles. The
// compiler picks the correct overload automatically based on the arguments
// passed, making call sites read naturally and letting you reuse the same
// conceptual operation across related input shapes without duplicating the
// method's "identity" in its name.
public static class Exercise02_CalculatorOverload
{
    public class Calculator
    {
        public int Sum(int a, int b) => a + b;

        public int Sum(int a, int b, int c) => a + b + c;

        public double Sum(double a, double b) => a + b;
    }

    public static void Run()
    {
        Calculator calc = new();

        Console.WriteLine($"Sum(2, 3) = {calc.Sum(2, 3)}");
        Console.WriteLine($"Sum(2, 3, 4) = {calc.Sum(2, 3, 4)}");
        Console.WriteLine($"Sum(2.5, 3.7) = {calc.Sum(2.5, 3.7)}");
    }
}
