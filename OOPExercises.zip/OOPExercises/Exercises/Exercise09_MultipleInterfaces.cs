namespace OOPExercises.Exercises;

// Q: How does C# overcome the limitation of single inheritance with
// interfaces?
// C# classes can only inherit from ONE base class, but they can implement
// as MANY interfaces as needed. Since interfaces just define contracts
// (what a type can do) rather than concrete implementation state, a class
// can freely combine multiple unrelated capabilities -- e.g. being both
// IReadable and IWritable -- without the diamond-inheritance ambiguity
// problems that multiple class inheritance would cause. This gives most of
// the flexibility of multiple inheritance while keeping implementation
// inheritance simple and unambiguous.
public static class Exercise09_MultipleInterfaces
{
    public interface IReadable
    {
        void Read();
    }

    public interface IWritable
    {
        void Write();
    }

    public class File : IReadable, IWritable
    {
        public string Name { get; set; }

        public File(string name)
        {
            Name = name;
        }

        public void Read()
        {
            Console.WriteLine($"Reading from {Name}...");
        }

        public void Write()
        {
            Console.WriteLine($"Writing to {Name}...");
        }
    }

    public static void Run()
    {
        File file = new("report.txt");
        file.Read();
        file.Write();

        // Can also be accessed through either interface reference:
        IReadable reader = file;
        IWritable writer = file;
        reader.Read();
        writer.Write();
    }
}
