﻿using System;

namespace ArrayExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            Region1_ArrayInitialization();
            Region2_ShallowVsDeepCopy();
            Region3_StudentGrades2D();
            Region4_ArrayMethods();
            Region5_LoopVariants();
            Region6_InputValidation();
            Region7_MatrixFormatting();
            Region8_MonthNameLookup();
            Region9_SortAndSearch();
            Region10_SumComparison();

            Console.WriteLine("\nAll demos complete. Press any key to exit.");
            Console.ReadKey();
        }

        #region Region 1 - Array Initialization, Assignment, and IndexOutOfRangeException
        // Q: What is the default value assigned to array elements in C#?
        // A: For an int[] array created with `new int[size]`, every element is
        //    automatically initialized to the default value of the element type.
        //    For int (and other numeric value types) that default is 0.
        //    (bool defaults to false, reference types default to null, etc.)
        static void Region1_ArrayInitialization()
        {
            Console.WriteLine("=== Region 1: Array Initialization ===");

            // 1. new int[size] - elements default to 0 until assigned
            int[] arr1 = new int[5];
            Console.Write("arr1 defaults: ");
            foreach (int val in arr1) Console.Write(val + " ");
            Console.WriteLine();

            // 2. Initializer list
            int[] arr2 = { 10, 20, 30, 40, 50 };

            // 3. Array syntax sugar (implicitly typed array / collection expression style)
            var arr3 = new int[] { 1, 2, 3, 4, 5 };

            // Assign values to arr1
            for (int i = 0; i < arr1.Length; i++)
            {
                arr1[i] = (i + 1) * 100;
            }

            Console.Write("arr1 assigned: ");
            foreach (int val in arr1) Console.Write(val + " ");
            Console.WriteLine();

            Console.Write("arr2: ");
            foreach (int val in arr2) Console.Write(val + " ");
            Console.WriteLine();

            Console.Write("arr3: ");
            foreach (int val in arr3) Console.Write(val + " ");
            Console.WriteLine();

            // Demonstrate IndexOutOfRangeException
            try
            {
                Console.WriteLine("Attempting to access arr2[10]...");
                Console.WriteLine(arr2[10]);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("Caught exception: " + ex.Message);
            }

            Console.WriteLine();
        }
        #endregion

        #region Region 2 - Shallow Copy vs Deep Copy
        // Q: What is the difference between Array.Clone() and Array.Copy()?
        // A: Array.Clone() is an instance method that creates a brand-new array
        //    object containing copies of all the elements from the source array
        //    (a shallow copy - for value types the values themselves are duplicated,
        //    but for reference types only the references are copied, not the
        //    underlying objects). It returns the new array as an `object` that must
        //    be cast.
        //    Array.Copy() is a static method that copies a specified number of
        //    elements from a source array into an EXISTING destination array
        //    (which you must create beforehand). It lets you copy only a portion
        //    of the array and can copy between arrays of different but compatible
        //    types. Both Clone() and Copy() perform shallow copies; neither
        //    recursively duplicates objects referenced by array elements.
        static void Region2_ShallowVsDeepCopy()
        {
            Console.WriteLine("=== Region 2: Shallow vs Deep Copy ===");

            int[] arr1 = { 1, 2, 3, 4, 5 };

            // Shallow copy: arr2 is just another reference to the SAME array object
            int[] arr2 = arr1;
            Console.WriteLine("-- Shallow copy (reference assignment) --");
            arr2[0] = 999;
            Console.Write("arr1 after modifying arr2: ");
            foreach (int val in arr1) Console.Write(val + " ");
            Console.WriteLine("  <-- arr1 changed too, they share the same memory");
            Console.WriteLine();

            // Deep copy (for a value-type array, Clone() gives an independent copy)
            int[] original = { 10, 20, 30, 40, 50 };
            int[] cloned = (int[])original.Clone();

            Console.WriteLine("-- Deep copy using Clone() --");
            cloned[0] = 111;
            Console.Write("original: ");
            foreach (int val in original) Console.Write(val + " ");
            Console.WriteLine();
            Console.Write("cloned:   ");
            foreach (int val in cloned) Console.Write(val + " ");
            Console.WriteLine("  <-- original is unaffected, independent array");

            Console.WriteLine();
        }
        #endregion

        #region Region 3 - 2D Array of Student Grades
        // Q: What is the difference between GetLength() and Length for
        //    multidimensional arrays?
        // A: Length returns the TOTAL number of elements across all dimensions
        //    of the array (rows * columns for a 2D array). GetLength(dimension)
        //    returns the number of elements in a SPECIFIC dimension only
        //    (e.g., GetLength(0) = number of rows, GetLength(1) = number of
        //    columns). Use GetLength() when you need to iterate a particular
        //    dimension with nested loops; use Length when you just need the
        //    overall element count.
        static void Region3_StudentGrades2D()
        {
            Console.WriteLine("=== Region 3: 2D Array - Student Grades ===");

            int numStudents = 3;
            int numSubjects = 3;
            int[,] grades = new int[numStudents, numSubjects];

            // Using fixed/simulated input instead of Console.ReadLine() for a
            // non-interactive demo run. In an interactive console app, replace
            // the values below with int.Parse(Console.ReadLine()) inside the loop.
            int[,] simulatedInput = { { 85, 90, 78 }, { 72, 88, 95 }, { 60, 75, 82 } };

            for (int student = 0; student < grades.GetLength(0); student++)
            {
                for (int subject = 0; subject < grades.GetLength(1); subject++)
                {
                    // Console.Write($"Enter grade for student {student + 1}, subject {subject + 1}: ");
                    // grades[student, subject] = int.Parse(Console.ReadLine());
                    grades[student, subject] = simulatedInput[student, subject];
                }
            }

            for (int student = 0; student < grades.GetLength(0); student++)
            {
                Console.Write($"Student {student + 1} grades: ");
                for (int subject = 0; subject < grades.GetLength(1); subject++)
                {
                    Console.Write(grades[student, subject] + " ");
                }
                Console.WriteLine();
            }

            Console.WriteLine($"Total elements (Length): {grades.Length}");
            Console.WriteLine($"Rows (GetLength(0)): {grades.GetLength(0)}, Columns (GetLength(1)): {grades.GetLength(1)}");

            Console.WriteLine();
        }
        #endregion

        #region Region 4 - Array Methods Demo
        // Q: What is the difference between Array.Copy() and
        //    Array.ConstrainedCopy()?
        // A: Array.Copy() copies elements from a source array to a destination
        //    array; if a type-compatibility problem or overflow is discovered
        //    partway through, the destination array may be left partially
        //    modified. Array.ConstrainedCopy() performs the same kind of copy
        //    but offers a strong exception guarantee (atomicity): if the copy
        //    cannot be completed successfully, the destination array is left
        //    completely unchanged, as if the copy never happened. This makes
        //    ConstrainedCopy() useful in constrained execution regions where
        //    reliability guarantees matter.
        static void Region4_ArrayMethods()
        {
            Console.WriteLine("=== Region 4: Array Methods (Sort, Reverse, IndexOf, Copy, Clear) ===");

            int[] numbers = { 40, 10, 30, 50, 20 };
            Console.Write("Original array: ");
            PrintArray(numbers);

            // 1. Sort
            int[] sorted = (int[])numbers.Clone();
            Array.Sort(sorted);
            Console.Write("After Array.Sort(): ");
            PrintArray(sorted);
            Console.WriteLine("  -> Elements rearranged into ascending order.");

            // 2. Reverse
            int[] reversed = (int[])sorted.Clone();
            Array.Reverse(reversed);
            Console.Write("After Array.Reverse(): ");
            PrintArray(reversed);
            Console.WriteLine("  -> Order of elements flipped (now descending, since it was sorted).");

            // 3. IndexOf
            int index = Array.IndexOf(numbers, 30);
            Console.WriteLine($"Array.IndexOf(numbers, 30) = {index}  -> Finds the first position of value 30.");

            // 4. Copy
            int[] destination = new int[numbers.Length];
            Array.Copy(numbers, destination, numbers.Length);
            Console.Write("After Array.Copy() into destination: ");
            PrintArray(destination);
            Console.WriteLine("  -> destination now holds the same values as numbers (independent array).");

            // 5. Clear
            int[] toClear = (int[])numbers.Clone();
            Array.Clear(toClear, 0, toClear.Length);
            Console.Write("After Array.Clear(): ");
            PrintArray(toClear);
            Console.WriteLine("  -> All elements reset to default value (0 for int).");

            Console.WriteLine();
        }

        static void PrintArray(int[] arr)
        {
            foreach (int val in arr) Console.Write(val + " ");
            Console.WriteLine();
        }
        #endregion

        #region Region 5 - for, foreach, and while Loops
        // Q: Why is foreach preferred for read-only operations on arrays?
        // A: foreach expresses intent clearly (iterate every element, don't
        //    modify the collection or use an index), which makes code more
        //    readable and less error-prone (no off-by-one or index bound
        //    mistakes). The compiler/JIT special-cases arrays so foreach over
        //    an array is optimized to perform about as well as a manual for
        //    loop. Since the iteration variable in foreach is effectively
        //    read-only, it also prevents accidental reassignment of elements,
        //    reinforcing that the loop is meant only to read values.
        static void Region5_LoopVariants()
        {
            Console.WriteLine("=== Region 5: for / foreach / while Loops ===");

            int[] arr = { 5, 10, 15, 20, 25 };

            Console.Write("for loop:      ");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }
            Console.WriteLine();

            Console.Write("foreach loop:  ");
            foreach (int val in arr)
            {
                Console.Write(val + " ");
            }
            Console.WriteLine();

            Console.Write("while (reverse): ");
            int index = arr.Length - 1;
            while (index >= 0)
            {
                Console.Write(arr[index] + " ");
                index--;
            }
            Console.WriteLine();

            Console.WriteLine();
        }
        #endregion

        #region Region 6 - Defensive Input Validation
        // Q: Why is input validation important when working with user inputs?
        // A: Users can (and will) type unexpected or malformed data, whether by
        //    accident or intentionally. Validating input prevents the program
        //    from crashing with unhandled exceptions (like FormatException),
        //    protects data integrity by ensuring only values that satisfy the
        //    program's business rules are accepted, improves the user
        //    experience by giving clear feedback instead of a crash, and
        //    reduces security risks (unvalidated input is a common vector for
        //    injection attacks and other exploits).
        static void Region6_InputValidation()
        {
            Console.WriteLine("=== Region 6: Defensive Input Validation ===");

            // Simulated inputs to demonstrate the validation loop without blocking
            // on real Console.ReadLine() calls. Replace `simulatedInputs` usage
            // with actual Console.ReadLine() in an interactive console app.
            string[] simulatedInputs = { "abc", "-7", "4", "7" };
            int simIndex = 0;
            int number;
            bool isValid;

            do
            {
                string input = simulatedInputs[simIndex++];
                Console.WriteLine($"User enters: \"{input}\"");

                isValid = int.TryParse(input, out number) && number > 0 && number % 2 != 0;

                if (!isValid)
                {
                    Console.WriteLine("Invalid input. Please enter a positive odd number.");
                }
            }
            while (!isValid && simIndex < simulatedInputs.Length);

            if (isValid)
                Console.WriteLine($"Accepted valid positive odd number: {number}");
            else
                Console.WriteLine("No valid input was provided in this demo run.");

            Console.WriteLine();
        }
        #endregion

        #region Region 7 - 2D Array Matrix Formatting
        // Q: How can you format the output of a 2D array for better readability?
        // A: Use consistent column widths so values line up, e.g. via
        //    string.Format/composite formatting or interpolated strings with
        //    alignment component like $"{value,5}" (pads to a fixed width),
        //    or PadLeft()/PadRight(). Printing a newline after each row (using
        //    nested loops - outer loop for rows, inner loop for columns) keeps
        //    the matrix shape visible. Adding row/column headers and separators
        //    (e.g., "-----") further improves readability for larger matrices.
        static void Region7_MatrixFormatting()
        {
            Console.WriteLine("=== Region 7: 2D Array Matrix Formatting ===");

            int[,] matrix =
            {
                { 1, 2, 3 },
                { 4, 5, 6 },
                { 7, 8, 9 }
            };

            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    Console.Write($"{matrix[row, col],4}"); // right-align in a 4-char field
                }
                Console.WriteLine();
            }

            Console.WriteLine();
        }
        #endregion

        #region Region 8 - Month Name Lookup (if-else vs switch)
        // Q: When should you prefer a switch statement over if-else?
        // A: Prefer switch when you're comparing a SINGLE variable/expression
        //    against many discrete, known constant values (like month numbers
        //    1-12). Switch statements are generally more readable at that
        //    scale than a long if-else-if chain, clearly show all handled
        //    cases plus a default, and the compiler can sometimes optimize
        //    them into a jump table for better performance with many cases.
        //    if-else remains preferable for range checks, complex boolean
        //    conditions, or comparisons involving multiple different
        //    variables, since switch is not well suited to those patterns.
        static void Region8_MonthNameLookup()
        {
            Console.WriteLine("=== Region 8: Month Name Lookup ===");

            int monthNumber = 4; // simulated user input

            // if-else version
            string monthNameIfElse;
            if (monthNumber == 1) monthNameIfElse = "January";
            else if (monthNumber == 2) monthNameIfElse = "February";
            else if (monthNumber == 3) monthNameIfElse = "March";
            else if (monthNumber == 4) monthNameIfElse = "April";
            else if (monthNumber == 5) monthNameIfElse = "May";
            else if (monthNumber == 6) monthNameIfElse = "June";
            else if (monthNumber == 7) monthNameIfElse = "July";
            else if (monthNumber == 8) monthNameIfElse = "August";
            else if (monthNumber == 9) monthNameIfElse = "September";
            else if (monthNumber == 10) monthNameIfElse = "October";
            else if (monthNumber == 11) monthNameIfElse = "November";
            else if (monthNumber == 12) monthNameIfElse = "December";
            else monthNameIfElse = "Invalid month";

            Console.WriteLine($"if-else result: {monthNameIfElse}");

            // switch version
            string monthNameSwitch;
            switch (monthNumber)
            {
                case 1: monthNameSwitch = "January"; break;
                case 2: monthNameSwitch = "February"; break;
                case 3: monthNameSwitch = "March"; break;
                case 4: monthNameSwitch = "April"; break;
                case 5: monthNameSwitch = "May"; break;
                case 6: monthNameSwitch = "June"; break;
                case 7: monthNameSwitch = "July"; break;
                case 8: monthNameSwitch = "August"; break;
                case 9: monthNameSwitch = "September"; break;
                case 10: monthNameSwitch = "October"; break;
                case 11: monthNameSwitch = "November"; break;
                case 12: monthNameSwitch = "December"; break;
                default: monthNameSwitch = "Invalid month"; break;
            }

            Console.WriteLine($"switch result:  {monthNameSwitch}");

            Console.WriteLine();
        }
        #endregion

        #region Region 9 - Sort and Search
        // Q: What is the time complexity of Array.Sort()?
        // A: Array.Sort() for a plain array of primitives (like int[]) uses an
        //    introspective sort (introsort) internally - a hybrid that starts
        //    with quicksort, switches to heapsort if recursion gets too deep
        //    (to avoid quicksort's O(n^2) worst case), and uses insertion sort
        //    for small partitions. Its average and worst-case time complexity
        //    is O(n log n), and it is not a stable sort.
        static void Region9_SortAndSearch()
        {
            Console.WriteLine("=== Region 9: Sort and Search ===");

            int[] numbers = { 8, 3, 8, 1, 9, 3, 5 };
            Console.Write("Before sort: ");
            PrintArray(numbers);

            Array.Sort(numbers);
            Console.Write("After sort:  ");
            PrintArray(numbers);

            int firstIndex = Array.IndexOf(numbers, 3);
            int lastIndex = Array.LastIndexOf(numbers, 3);

            Console.WriteLine($"Array.IndexOf(numbers, 3) = {firstIndex}");
            Console.WriteLine($"Array.LastIndexOf(numbers, 3) = {lastIndex}");

            Console.WriteLine();
        }
        #endregion

        #region Region 10 - Sum via for vs foreach
        // Q: Which loop (for or foreach) is more efficient for calculating the
        //    sum of an array, and why?
        // A: For arrays specifically, they are essentially equivalent in
        //    performance. The C# compiler/JIT recognizes foreach over an array
        //    and optimizes it into the same kind of indexed loop a hand-written
        //    for loop would use (including bounds-check elimination in many
        //    cases), so there is no meaningful runtime difference for arrays.
        //    (The efficiency gap only becomes noticeable with other collection
        //    types like List<T> accessed through IEnumerable<T>, where foreach
        //    incurs enumerator overhead that a for loop with direct indexing
        //    avoids.) Given that, foreach is often preferred for simple sum
        //    calculations because it is more concise and readable, with no
        //    performance penalty for arrays.
        static void Region10_SumComparison()
        {
            Console.WriteLine("=== Region 10: Sum via for vs foreach ===");

            int[] arr = { 2, 4, 6, 8, 10 };

            int sumFor = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sumFor += arr[i];
            }
            Console.WriteLine($"Sum using for loop:     {sumFor}");

            int sumForeach = 0;
            foreach (int val in arr)
            {
                sumForeach += val;
            }
            Console.WriteLine($"Sum using foreach loop: {sumForeach}");

            Console.WriteLine();
        }
        #endregion

        #region Extra Task (pending details)
        // NOTE: The prompt asked for an additional, unrelated region containing
        // "the following task", but the task description was not included in
        // the message (it cut off after the colon). Please provide the task
        // details and this region will be filled in accordingly.
        #endregion
    }
}